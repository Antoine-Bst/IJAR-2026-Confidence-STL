/* ============================================================================
 * D Y N I B E X - SIMULATION FILE
 * ============================================================================
 * Copyright   : ENSTA
 * License     : This program can be distributed under the terms of the GNU LGPL.
 *               See the file COPYING.LESSER.
 *
 * Author(s)   : Antoine Besset, Joris Tillet and Julien Alexandre dit Sandretto
 * Created     : Sept 30, 2025
 * Modified    : Nov 17, 2025
 * Sponsored   : This research benefited from the support of the "STARTS Projects - CIEDS - Institut Polytechnique"
 * ---------------------------------------------------------------------------- */

#include "ibex.h"
#include "ZonoIbex.h"
#include <iostream>
#include <list>
#include "CSTL.h"
#include "CSTL_Robust.h"
#include "ZonoSimu.h"
#include "DnnAff.h"

#include <memory>


using namespace ibex;
using namespace std;

struct partial_sim {
    std::vector<Affine2Vector> last_aff;
    ZonoTube Tube;

    partial_sim(ibex::simulation& simu)
      : Tube(simu) 
    {
        last_aff.push_back(simu.get_last_aff());
    }
};

//==============Fonction de reduction de taille de tube===============

Affine2Vector dim_reduction_affDyn(const Affine2Vector& affvec, const int& n_dim){
Affine2Vector result(n_dim);

for (size_t i = 0; i < n_dim; i++)
{
  result[i] = affvec[i];
}
return result;
}

std::vector<Affine2Vector> Tube_dim_reduction_affDyn(const std::vector<Affine2Vector>& init, const int& n_dim){
  std::vector<Affine2Vector> result;
  for (size_t i = 0; i < init.size(); i++)
  {
    result.push_back(dim_reduction_affDyn(init[i], n_dim));
  }
  return result;
}

Aff2Vec dim_reduction_Aff2Vec(const Aff2Vec& affvec, const int& n_dim){
Aff2Vec result(n_dim);

for (size_t i = 0; i < n_dim; i++)
{
  result[i] = affvec[i];
}
return result;
}

std::vector<Aff2Vec> Tube_dim_reduction_Aff2Vec(const std::vector<Aff2Vec>& init, const int& n_dim){
  std::vector<Aff2Vec> result;
  for (size_t i = 0; i < init.size(); i++)
  {
    result.push_back(dim_reduction_Aff2Vec(init[i], n_dim));
  }
  return result;
}

IntervalVector dim_reduction_jnItv(const IntervalVector& affvec, const int& n_dim){
IntervalVector result(n_dim);

for (size_t i = 0; i < n_dim; i++)
{
  result[i] = affvec[i];
}
return result;
}

std::vector<IntervalVector> Tube_dim_reduction_jnItv(const std::vector<IntervalVector>& init, const int& n_dim){
  std::vector<IntervalVector> result;
  for (size_t i = 0; i < init.size(); i++)
  {
    result.push_back(dim_reduction_jnItv(init[i], n_dim));
  }
  return result;
}

ZonoTube Merge_tube_reduc(const ZonoTube& init, const ZonoTube& addi, const int& n_dim){

  ZonoTube result = init;
  if (result.aff[0].size()!=n_dim || result.zono[0].size()!=n_dim || result.jn[0].size()!=n_dim) //si une reduction à déjà été faites alors on skip
  {
    result.aff = Tube_dim_reduction_affDyn(result.aff, n_dim);
    result.zono = Tube_dim_reduction_Aff2Vec(result.zono, n_dim);
    result.jn = Tube_dim_reduction_jnItv(result.jn, n_dim);
  }

  for (size_t i = 0; i < addi.aff.size(); i++)
  {
    result.aff.push_back(dim_reduction_affDyn(addi.aff[i], n_dim));
  }

  for (size_t i = 0; i < addi.zono.size(); i++)
  {
    result.zono.push_back(dim_reduction_Aff2Vec(addi.zono[i], n_dim));
  }
  for (size_t i = 0; i < addi.jn.size(); i++)
  {
    result.jn.push_back(dim_reduction_jnItv(addi.jn[i], n_dim));
  }
  double final_time = init.time.back().ub();

  for (size_t i = 0; i < addi.time.size(); i++)
  {
    result.time.push_back(addi.time[i]+ final_time);
  }
  
  return result;
}


Affine2Vector ponctual_affine_vector(const double& val, const int& dim){
     IntervalVector init_itv(dim);
     for (size_t i = 0; i < init_itv.size(); i++)
     {
      init_itv[i] = Interval(val);
     }     
     Affine2Vector init_aff(init_itv, true);
     return init_aff;
}

Affine2Main<AF_fAFFullI> ponctual_affine(const double& val){
     IntervalVector init_itv(1);
      init_itv[0] = Interval(val);  
     Affine2Vector init_aff(init_itv, true);
     return init_aff[0];
}

//====================Fin de fonction de reduction==================

ZonoTube Simulation_system(const Affine2Vector& yinit_aff){
    const int n= 2; ///nombre d'état dans le système différentiel
    Variable y(n);
    
      double tsimu=6;
      
      //---------------simulation--------------------
      Function ydot = Function(y,Return(-y[0] + 0.5*y[1]+1, -0.2*y[1] + 0.2*sin(y[0])+1)); //ibex::sin(y[0])
      ivp_ode problem = ivp_ode(ydot,0.0,yinit_aff);
      simulation simu = simulation(&problem,tsimu,RK4,1e-8, 1e-5);

      simu.run_simulation();
      ZonoTube result(simu);

      return result; //on construit l'objet tube
}

ZonoTube Simulation_system_adapt(const Affine2Vector& yinit_aff, const double& ministep ,const std::vector<IntervalVector>& predicate_liste_itv){
    const int n= 2; ///nombre d'état dans le système différentiel
    Variable y(n);
    
      double tsimu=6;
      
      //---------------simulation--------------------
      Function ydot = Function(y,Return(-y[0] + 0.5*y[1]+1, -0.2*y[1] + 0.2*sin(y[0])+1)); //ibex::sin(y[0])
      ivp_ode problem = ivp_ode(ydot,0.0,yinit_aff);
      simulation simu = simulation(&problem,tsimu,RK4,1e-8, 1e-5);

      simu.run_simulation();
      vector<double> Bisectime;
      double satisfaction_at_t;
      //adaptative time sampling
      do
      {
      std::pair<std::vector<Satisfaction_Signal>, std::vector<Interval>> root_signals = predicate_satisfaction(simu, predicate_liste_itv);
      Satisfaction_Signal phi = STL_formula(root_signals.first);

      vector<Interval> bisection = Uncertainty_origin(phi, root_signals.second);
      Bisectime = Bisection_time(bisection, ministep, 0);

      satisfaction_at_t = satisfies_at_time(0, phi);

      for (size_t i = 0; i < Bisectime.size(); i++)
        {
          std::cout<< Bisectime[i]<<" , ";
          simu.get_tight(Bisectime[i]);
        }

      } while (!Bisectime.empty()&&(satisfaction_at_t==2||satisfaction_at_t==-2));

      ZonoTube result(simu);
      
      //IntervalVector picard_norm = Interval(0,1)*simu.eval_vector_j(result.jn[10]);
  

      //cout<<picard_norm<<"evaluation picard"<<endl;

      return result; //on construit l'objet tube
}


partial_sim simulation_Dyn(const std::vector<Affine2Vector>& Inputs, const Affine2Vector& Initial_Value, const int& num)
{
    const int n= 8; ///nombre d'état dans le système différentiel
    Variable y(n);
    IntervalVector yinit(n);
    yinit[0] = Interval(0);  //x
    yinit[1] = Interval(0);   //y
    yinit[2] = Interval(0);  //u'
    yinit[3] = Interval(0);  //v'
    yinit[4] = Interval(2);  //u_ref
    yinit[5] = Interval(1);  //v_ref
    yinit[6] = Interval(0);  //uncertainty
    yinit[7] = Interval(0);  //uncertainty

  AF_fAFFullI::setAffineNoiseNumber(500);
  Affine2Vector yinit_aff(yinit, true);

    yinit_aff[0] = Initial_Value[0];
    yinit_aff[1] = Initial_Value[1];
    yinit_aff[2] = Initial_Value[2];
    yinit_aff[3] = Initial_Value[3];
    yinit_aff[4] = Inputs[0][0];
    yinit_aff[5] = Inputs[1][0];
    yinit_aff[6] = Initial_Value[6];
    yinit_aff[7] = Initial_Value[7];
    
    //cout<<"input NN 1 "<<yinit_aff[4]<<endl;
    //cout<<"input NN 2 "<<yinit_aff[5]<<endl;

    const double K_v = 2.1;
    const double K_c = 6;

    Interval Const = Interval(0);

    const double tsimu=0.5;

    Function ydot = Function(y,Return(
      ibex::cos(y[3])*y[2], ibex::sin(y[3])*y[2], y[7]*(y[4] - y[2]), K_c*(y[5]- y[3]) + y[6], Const, Const, Const, Const
      ));
      ivp_ode problem = ivp_ode(ydot,0.0,yinit_aff);    
      simulation simu = simulation(&problem,tsimu,RK4,1e-9);

      simu.run_simulation();
    std::cout<< "-----end of simudyn-----"<<std::endl;
      yinit_aff = simu.get_last_aff();

    partial_sim result (simu);

    result.last_aff = {yinit_aff}; //au cas ou à enlever après

return result;
}

//const Affine2Vector& yinit_aff
ZonoTube Simulation_system_NN(const Affine2Vector& init_aff){

    const int n= 8; ///nombre d'état dans le système différentiel
    Variable y(n);

    Affine2Vector yinit_aff = ponctual_affine_vector(0.0, n); //initialisation

    yinit_aff = init_aff;

    Affine2Vector uncertainty_aff = ponctual_affine_vector(0.0, 2);
    uncertainty_aff[0] = yinit_aff[6]; //assign the corresponding affine form to the uncertainty
    uncertainty_aff[1] = yinit_aff[7];

    vector<double> init_cond = {0.0,0.0,0.0};
    std::vector<Affine2Vector> Inputs;

    for (size_t i = 0; i < init_cond.size(); i++)
    {
        IntervalVector tempor(1); //temporary variable
        tempor[0] = Interval(init_cond[i]); //on passe le temps dans les états pour le NN
        Affine2Vector tempor_aff(tempor, true);
        Inputs.push_back(tempor_aff);
    }
    
    std::vector<Affine2Vector> output = DeepNeuralNetwork_aff(Inputs , "weights.txt", "biases.txt");
    
    partial_sim result = simulation_Dyn(output, yinit_aff, 0);
    ZonoTube sim_out = result.Tube; //initialisation
      yinit_aff = result.last_aff[0];
    double last_time = 0.5;

    cout<<"Début de la boucle de simu"<<last_time<<endl;
    for (int i = 0; i < 19; i++)
    {   
        Inputs[0][0] = yinit_aff[0]; //x
        Inputs[1][0] = yinit_aff[1]; //y
        Inputs[2][0] = ponctual_affine(last_time); //temps stocker en dernière position

        output = DeepNeuralNetwork_aff(Inputs , "weights.txt", "biases.txt");

        yinit_aff[6] = uncertainty_aff[0];
        yinit_aff[7] = uncertainty_aff[1];

        std::cout<<"---------------simulation---------------"<<i<<std::endl;
        partial_sim result = simulation_Dyn(output, yinit_aff, i+1);
        yinit_aff = result.last_aff[0];


        sim_out = Merge_tube_reduc(sim_out,result.Tube, 2);
        last_time = sim_out.time.back().ub();

        cout<<"temps de fin : "<<last_time<<endl;
    }
    return sim_out;
    }
