#ifndef ZONOIBEX_H
#define ZONOIBEX_H

/* ============================================================================
 * D Y N I B E X - QuickComputation of Zonotope from Dynibex
 * ============================================================================
 * License     : GNU LGPL (see COPYING.LESSER)
 * Authors     : Antoine Besset, Joris Tillet, Julien Alexandre dit Sandretto
 * Created     : Sept 30, 2025
 * Modified    : Sept 30, 2025
 * ---------------------------------------------------------------------------- */

#include "ibex.h"
#include <vector>
#include <utility>
#include "CSTL.h"
#include "CSTL_Robust.h"


using namespace ibex;
using namespace std;

const int n_reduction_zonotope = 12; //valeur par défaut pour la representation dans un tube
const int nombre_dimension_plot = 2;

// ======================== Data structures ======================== //

struct PointCloud {
    std::vector<std::vector<double>> cloud;
    // point + combinaison des générateurs l'ayant produit
    std::vector<std::pair<std::vector<double>, std::vector<int>>> cloud_origin;
};

struct AffineDecomp {
    double center;
    std::vector<std::pair<int,double>> coeffs;
    ibex::Interval garbage;

    void build_aff(double c,
    const std::vector<std::pair<int,double>>& coe,
    ibex::Interval g = ibex::Interval(0.0)){
        center = c;
        coeffs = coe;
        garbage = g;
            }

};

typedef std::vector<AffineDecomp> Aff2Vec;

typedef std::pair<std::vector<std::vector<double>>, std::vector<std::vector<double>>> ItvMatrix; //usefull data structure to solve the LP problem
typedef std::pair<std::vector<double>, std::vector<double>> ItvVector; //usefull data structure to solve the LP problem

struct proba_gen
{
  double mu;
  double sigma;
  int num_gen;
  proba_gen(const int& cnum_gen, const double& cmu, const double& csigma){
    mu = cmu;
    sigma = csigma;
    num_gen = cnum_gen;
  }
};

//======STL======
typedef pair<pair<int, vector<int>>, pair<double, double>> TimeInterval;
typedef std::vector<TimeInterval> Satisfaction_Signal;

typedef pair<double, pair<double, double>> RobustInterval;
typedef vector<RobustInterval> Robust_Signal;

Aff2Vec
DyniAff2Vec(const ibex::Affine2Vector& aff_vec);

ibex::IntervalVector to_hull(const Aff2Vec& aff_vec);

struct ZonoTube {
    std::vector<Interval> time;        // ou double si tu veux juste t_n ou t_{n+1}
    std::vector<Affine2Vector> aff;   // format dynibex
    std::vector<Aff2Vec> zono;   //  format perso
    std::vector<ibex::IntervalVector> jn; //boite pour la robustesse
    
    //std::vector<Affine2Vector> jn_aff;   // état au début du pas (corrélé)
    //std::vector<Affine2Vector> jnh_aff;  // (optionnel mais très utile) état à la fin du pas

    ZonoTube(ibex::simulation& simu){
      for (Affine2Vector z : simu.zonotopicard) {
        //AF_fAFFullI::setAffineNoiseNumber(n_reduction_zonotope);
        //z.compact(); //on limite le nombre de terme de bruit
      aff.push_back(z);
      zono.push_back(DyniAff2Vec(z));
      jn.push_back(to_hull(DyniAff2Vec(z)));
      }
      for (const Interval& t : simu.zonotopicard_time) {
      time.push_back(t);
      }
      if (!time.empty())
      {
        time[0] = Interval(0); ///on supprime le pas négatif initial
      }
      //for (const auto& sol : simu.list_solution_g) {
      //  if (sol.box_jn) 
      //  { // Ensure it's not NULL
      //      jn.push_back(*sol.box_j1); // Dereference pointer
      //  }
    }
    void compact(const int& n_compact){
        AF_fAFFullI::setAffineNoiseNumber(n_compact);
        for (size_t i = 0; i < aff.size(); i++)
        {
          aff[i].compact();
          zono[i]=(DyniAff2Vec(aff[i]));
          jn[i] = to_hull(DyniAff2Vec(aff[i]));
        }
    }
};

typedef std::vector<proba_gen> proba_space;

// ======================== Function declarations ======================== //

bool areEqual(const std::vector<double>& v1,
              const std::vector<double>& v2);

std::vector<std::vector<double>>
computeConvexHullVertices(const std::vector<std::vector<double>>& point_cloud);

void printAffineDecomp(const AffineDecomp& a);

void printAffineVector(const Aff2Vec& vec);

void print_vertices(std::vector<std::vector<double>>cloud);

void print_vertices_to_file(const ZonoTube& tube, const int& num_noise, const int& n);
void print_vertices_to_file_without_dim(const ZonoTube& tube, const int& n);
void print_vertices_to_file_as_3d_point_cloud(const ZonoTube& tube, const int& n);

void print_zonotube_to_file(const ZonoTube& tube, const int& num_noise);

ibex::Affine2Main<ibex::AF_fAFFullI>
make_affine(double center,
            const std::vector<std::pair<int,double>>& coeffs,
            ibex::Interval garbage = ibex::Interval(0.0));

AffineDecomp
decompose_affine(const ibex::Affine2Main<ibex::AF_fAFFullI>& a);

Aff2Vec Interval2Aff(const IntervalVector& itv_vec);

std::vector<std::vector<int>>
generate_sign_combinations(int N);

std::vector<double>
add_vector(const std::vector<double>& v1,
           const std::vector<double>& v2);

std::vector<double>
gain_vector(const std::vector<double>& v1,
            const int& K);

std::vector<double> gain_vector_double(const std::vector<double>& v1, const double& K);

double dot_vector(const std::vector<double>& a, const std::vector<double>& b);

std::vector<double> element_product(const std::vector<double>& a, const std::vector<double>& b);

ibex::Affine2Vector Aff2VecDyn(const Aff2Vec& aff_vec);

std::vector<double>
get_center_aff2vec(const Aff2Vec& affine_vector);

std::vector<std::vector<double>>
build_generators(const Aff2Vec& aff_vec);

PointCloud candidate_vertices(const Aff2Vec& affine_vector);

PointCloud Affine2Vertices(const Aff2Vec& aff_vec);

double norm_vec(std::vector<double> vec);

double dist_hull(const Aff2Vec& aff_vec, const std::vector<double>& dir);

Aff2Vec merge_zono(const Aff2Vec& aff_vec1, const Aff2Vec& aff_vec2);

bool is_in_list(const std::vector<int>& gen_num, const int& num);

bool is_include(const Aff2Vec& aff_vec, const std::vector<double>& x);

bool is_intersect(const Aff2Vec& aff_vec1, const Aff2Vec& aff_vec2);

bool is_subset(const Aff2Vec& aff_vec1, const Aff2Vec& aff_vec2);

double get_noise_val(std::vector<std::pair<int,double>> coeffs, const int& num);

int predicate_no(const int& marker, const int& init_marker);

std::vector<double> get_ub(ibex::IntervalVector temp);

std::vector<double> get_lb(ibex::IntervalVector temp);

ibex::IntervalVector garbage_to_box(const std::vector<int>& gen_num, const Aff2Vec& aff_vec);

ibex::IntervalVector Pontryagin_diff(ibex::IntervalVector vec1, ibex::IntervalVector vec2);

std::pair<std::vector<double>,std::vector<double>> pred_garb_min(const ibex::IntervalVector& garbage, const ibex::IntervalVector& predicate, const std::vector<double>& offset);

std::pair<std::vector<vector<double>>, std::vector<vector<double>>> Aff2Vec_to_Mat(std::vector<int> gen_num, const Aff2Vec& aff_vec);

std::vector<IntervalVector> constraints_selector(const IntervalVector& predicate, const std::vector<double>& point);

std::vector<double> solve_lp_glpk( //à utiliser pour trouver le zonotope optimale
    const std::pair<std::vector<std::vector<double>>, std::vector<std::vector<double>>>& A,
    const std::pair<std::vector<double>, std::vector<double>>& B,
    const std::vector<double>& c, const ibex::IntervalVector& limit);

std::vector<double> solve_milp_glpk_intersect(
    const std::vector<std::vector<double>>& G,   // m x n
    const std::vector<double>& P,                // m
    const std::vector<double>& c,                // n
    const ibex::IntervalVector& limit,           // n
    int K                                        // nb segments (>=2)
);

Aff2Vec Predicate_constraints(const Aff2Vec& state, const Aff2Vec& predicate, const proba_space& param, const vector<double> xsigma);

std::vector<double> Inclusion_LP(const std::vector<double>& coeff_fct, const Aff2Vec& state, const Aff2Vec& predicate, const std::vector<int>& genenum, const ibex::IntervalVector& limit);

std::vector<double> Multi_Inclusion_LP(const std::vector<double>& coeff_fct, const ZonoTube& tube, const std::vector<Aff2Vec>& predicates, const std::vector<int>& genenum, const ibex::IntervalVector& limit, const std::vector<int>& markers, const int& init_marker, const proba_space& param, const vector<double>& scaling);
std::vector<double> Multi_Exclusion_LP(const std::vector<double>& coeff_fct, const ZonoTube& tube, const std::vector<Aff2Vec>& predicates, const std::vector<int>& genenum, const ibex::IntervalVector& limit, const std::vector<int>& markers, const int& init_marker);

std::vector<double> Exclusion_LP(const std::vector<double>& coeff_fct, const Aff2Vec& reach_set, const Aff2Vec& predicate, const std::vector<int>& genenum, const ibex::IntervalVector& limit, const int& K);

std::vector<double> Coeff_generator(const proba_space& space, const std::vector<double>& point, const std::vector<double>& x_sigma);

std::vector<int> NumGen_generator(proba_space space);

double normal_cdf(double x);
double gaussian_pdf(double x, double mu, double sigma2);
double interval_prob(double a, double b, double mu, double sigma);


Aff2Vec gene_gain(const Aff2Vec& aff_vec,
                  const std::vector<std::pair<int, double>>& selection);

ZonoTube tube_gene_gain(const ZonoTube& tube, const std::vector<std::pair<int, double>>& selection, const int& noise_num);

Aff2Vec IntervalVector_to_Aff(ibex::IntervalVector itv_vec);

std::vector<std::pair<int, double>> reduction_to_selection(std::vector<double> reduction_liste);

std::vector<int> merge_vectors(const std::vector<int>& a,
                               const std::vector<int>& b);

std::pair<std::vector<std::vector<int>>,std::vector<int>> markers_compactator(const std::vector<int>& list, const int& groupesize);

std::vector<std::vector<int>> markers_decompactator(const std::pair<std::vector<std::vector<int>>,std::vector<int>>& input, const std::vector<std::vector<int>>& compact_combos);

std::vector<int> marker_temporal_cleaner(const ZonoTube& tube, const double& t, const std::vector<int>& init_list, const std::vector<Interval>& predicate_horizon, const int& tube_len);

std::pair<double, std::vector<double>> get_optimal_scaling_vector(const ZonoTube& tube, const double& time, const std::vector<Aff2Vec>& predicate_liste, const std::vector<Interval>& predicate_horizon,const proba_space& param, const std::vector<double>& xsigma , const double& criterion, const bool& trigger ,const int& tube_len);
std::pair<double, std::vector<double>> parameter_set_STL_r(ZonoTube tube, proba_space param, const std::vector<Aff2Vec>& predicates, const std::vector<int>& markers, const std::vector<double>& xsigma, const double& criterion ,const int& init_marker);

std::pair<double, std::vector<double>> get_optimal_scaling_vector(const ZonoTube& tube, const double& time, const std::vector<Aff2Vec>& predicate_liste, const std::vector<Interval>& predicate_horizon,const proba_space& param, const std::vector<double>& xsigma, const double& criterion ,const int& tube_len);

std::pair<double, std::vector<double>> get_overshoot_scaling_vector(const ZonoTube& tube, const double& time, const std::vector<Aff2Vec>& predicate_liste,const proba_space& param, const std::vector<double>& xsigma, const double& criterion ,const int& tube_len);

//=================STL==================

Satisfaction_Signal predicate_satisfaction_center(const ZonoTube& tube, const Aff2Vec& pset, const Satisfaction_Signal& origine ,const vector<int>& num, const int& init_marker);
Satisfaction_Signal predicate_satisfaction_tr(const ZonoTube& tube, const Aff2Vec& pset);
Satisfaction_Signal predicate_satisfaction_tracking(const ZonoTube& tube, const Aff2Vec& pset, const int& init_marker);

int predicate_test(const Aff2Vec& aff_vec1, const Aff2Vec& aff_vec2);

//================Robustesse STL================

std::vector<Robust_Signal> predicate_robust(const ZonoTube& tube, const std::vector<Aff2Vec>& predicate_liste);
int get_minimal_reachable_set(const ZonoTube& tube, const double& time, const std::vector<Aff2Vec>& predicate_liste, const int& tube_len);

#endif // ZONOIBEX_H
