/* ============================================================================
 * D Y N I B E X - COMPUTING SAFE SET OF PARAMETER FROM STL FORMULA
 * ============================================================================
 * Copyright   : ENSTA
 * License     : This program can be distributed under the terms of the GNU LGPL.
 *               See the file COPYING.LESSER.
 *
 * Author(s)   : Antoine Besset, Joris Tillet and Julien Alexandre dit Sandretto
 * Created     : Sept 30, 2025
 * Modified    : Nov 17, 2025
 * Sponsored   : This research benefited from the support of the "STARTS Projects - CIEDS - Institut Polytechnique"
 * ---------------------------------------------------------------------------- */

#include "ibex.h"
#include "ZonoIbex.h"
#include <iostream>
#include <list>
#include "CSTL.h"
#include "CSTL_Robust.h"
#include "ZonoSimu.h"

#include "DnnAff.h"

#include <unordered_map>

#include <glpk.h>

using namespace ibex;
using namespace std;


int main() {

    const int dim_sys = 8;

    const int n = 2;
    IntervalVector predicate1(n);
    predicate1[0] = Interval(1.95, 1.99);
    predicate1[1] = Interval(1.70, 1.75);

    IntervalVector predicate2(n);
    predicate2[0] = Interval(0.05,0.20);
    predicate2[1] = Interval(0.85,1);

    std::vector<Aff2Vec> predicate_liste = {Interval2Aff(predicate1), Interval2Aff(predicate2)};


    Interval p1h = Interval(5.2,5.7);
    Interval p2h = Interval(3.5,10);
    std::vector<Interval> predicate_horizon = {p1h, p2h};

    proba_gen gen1(1, 0, 0.1); //num gene, moyenne, var
    proba_gen gen2(2, 0, 0.06); 

    proba_space param = {gen1, gen2};

    std::vector<double> scaling = {2.0,2.0};


    const int init_marker = 1000;
    
    double max_proba = 0.5;
    double old_proba=0;

    double counter_over = 0.0;
    double counter_under = 0.0;

    bool uncertainty_trig = true;
    //===============simulation===============
for (int i = 0; i < 20; i++)
{
    AF_fAFFullI::setAffineNoiseNumber(200);
    Affine2Vector yinit_aff = ponctual_affine_vector(0.0, dim_sys);

    yinit_aff[0] = make_affine(0.0, {{7, 0.0}});
    yinit_aff[1] = make_affine(0.0, {{8, 0.0}});
    yinit_aff[2] = make_affine(0.0, {{3, 0.0}});
    yinit_aff[3] = make_affine(0.0, {{4, 0.0}});
    yinit_aff[4] = make_affine(0.5, {{5, 0.0}});
    yinit_aff[5] = make_affine(0.0, {{6, 0.0}});
    yinit_aff[6] = make_affine(0.0, {{1, scaling[0]*param[0].sigma}});
    yinit_aff[7] = make_affine(2.1, {{2, scaling[1]*param[1].sigma}});


    cout<<"Launching sim =====>"<<endl;

   ZonoTube tube = Simulation_system_NN(yinit_aff);
   tube.compact(10);

    cout<<"Sim finished =====>"<<endl;
    print_vertices_to_file_without_dim(tube, i);

    double conv_limit_overshoot = 2/(2+counter_over); ///upper limit for the successive convexification while performing overshoot to avoid instabilities due to nonlinearity
    double conv_limit_undershoot = 2/(2+counter_under);
    //peut etre faire une disjunction de cas en fonction du régime de certitude
    cout<<"===overshoot bound factor"<<conv_limit_overshoot<<endl;
    cout<<"===undershoot bound factor"<<conv_limit_undershoot<<endl;
    
    auto result = get_optimal_scaling_vector(tube, 0.0 ,predicate_liste, predicate_horizon, param, scaling, conv_limit_undershoot, uncertainty_trig,1000);
    if (!result.second.empty())
    {
      scaling = result.second;
      cout<< scaling[0] <<" ==scaling== "<<scaling[1]<<endl;
      uncertainty_trig = true; // c'est pour passer en monotonie d'inclusion dans l'exploration
      counter_over = counter_over + 1.0; //on limite l'overshoot au plus on passe en uncertain
    }
    else ///on est garantie la
    {
      uncertainty_trig = true; // on peut se repermettre d'overshoot dans l'uncertainty tracking
      counter_under = counter_under + 1.0; // on limite l'undershoot si on passe beaucoup en certain
      cout<<"===robustness overshooting==="<<endl;      
      result = get_overshoot_scaling_vector(tube, 0.0 ,predicate_liste, param, scaling, conv_limit_overshoot ,1000);
      
      scaling = result.second;
      cout<< scaling[0] <<" ==scaling== "<<scaling[1]<<endl;

      if (old_proba>max_proba)
        {
          max_proba = old_proba;
          cout<<old_proba<<" max proba"<<endl;
        }
    }

    old_proba = result.first;
    cout<<result.first<<" final "<< i <<endl;
    cout<<"printing to file"<<endl;
   print_zonotube_to_file(tube,10);
    tube.zono.push_back(predicate_liste[0]);
    tube.zono.push_back(predicate_liste[1]);
    print_vertices_to_file_without_dim(tube, i);

}   
    cout<<max_proba<<"========= max proba ========="<<endl;

    return 0;
}