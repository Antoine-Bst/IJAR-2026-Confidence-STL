/* ============================================================================
 * D Y N I B E X - ZONOTOPE MANIPULATION FOR DYNIBEX
 * ============================================================================
 * Copyright   : ENSTA
 * License     : This program can be distributed under the terms of the GNU LGPL.
 *               See the file COPYING.LESSER.
 *
 * Author(s)   : Antoine Besset, Joris Tillet and Julien Alexandre dit Sandretto
 * Created     : Sept 30, 2025
 * Modified    : Nov 17, 2025
 * Sponsored   : This research benefited from the support of the "STARTS Projects - CIEDS - Institut Polytechnique"
 * ---------------------------------------------------------------------------- */

#include "ibex.h"
#include "ZonoIbex.h"
#include <iostream>
#include <list>
#include "libqhullcpp/Qhull.h"
#include "libqhullcpp/QhullFacetList.h"
#include "libqhullcpp/QhullVertexSet.h"
#include <glpk.h>
#include <unordered_map>

using namespace orgQhull;
using namespace ibex;
using namespace std;

void print_vertices_to_file(const ZonoTube& tube, const int& num_noise, const int& n)
{
    std::ostringstream filename;
    filename << "/home/antoine-bc/Desktop/AutoParamSpace/AUTOGEN/simu_result/sim_zono" << n << ".txt";
    const int dim = 2; //applati en 2d

    std::ofstream sim_zono(filename.str());

    for (Aff2Vec vec: tube.zono)
    {
      sim_zono << "---"<<endl;
      
        auto temp = Affine2Vertices(vec);
        
        for (const auto& vertex : temp.cloud) {
          for (size_t i = 0; i < dim; i++) {  //vertex.size()
              sim_zono << vertex[i] << (i+1 < dim ? " " : "");
          }
          sim_zono << std::endl;
        }
      
    }
      sim_zono.close();
}


void print_vertices_to_file_without_dim(const ZonoTube& tube, const int& n)
{
  cout<<"filenames"<<endl;
    std::ostringstream filename;
    filename << "/home/antoine-bc/Desktop/AutoParamSpace/AUTOGEN/simu_result/sim_zono" << n << ".txt";

    std::ofstream sim_zono(filename.str());
   cout<<"computing vertices"<<endl;
   for (size_t j = 0; j < tube.zono.size(); j++)
   {
      sim_zono << "---"<<endl;
        auto temp = Affine2Vertices(tube.zono[j]);
        for (const auto& vertex : temp.cloud) {
          for (size_t i = 0; i < vertex.size(); i++) {
              sim_zono << vertex[i] << (i+1 < vertex.size() ? " " : "");
          }
          sim_zono << std::endl;
        }
      
    }
      sim_zono.close();
}


void print_vertices_to_file_as_3d_point_cloud(const ZonoTube& tube, const int& n)
{
    std::ostringstream filename;
    filename << "/home/antoine-bc/Desktop/AutoParamSpace/AUTOGEN/simu_result/"
             << "sim_zono" << n << "_3d.xyz"; // extension indicative

    std::ofstream out(filename.str());
    if (!out) {
        std::cerr << "Erreur: impossible d'ouvrir " << filename.str() << "\n";
        return;
    }

    for (size_t j = 0; j < tube.zono.size(); ++j)
    {
        auto temp = Affine2Vertices(tube.zono[j]);

        // Si tu veux séparer les paquets (facultatif, attention au parse)
        // out << "# --- zono " << j << "\n";

        for (const auto& vertex : temp.cloud)
        {
            const double x = (vertex.size() > 0) ? vertex[0] : 0.0;
            const double y = (vertex.size() > 1) ? vertex[1] : 0.0;
            const double z = (vertex.size() > 2) ? vertex[2] : 0.0;

            out << x << " " << y << " " << z << "\n";
        }
    }

    out.close();
}


void print_zonotube_to_file(const ZonoTube& tube, const int& num_noise)
{
    std::ofstream sim_zono;
    sim_zono.open("sim_aff.txt");

    for (Aff2Vec vec: tube.zono)
    {
      sim_zono << "---"<<endl;
      for (size_t i = 0; i < vec.size(); ++i) {
          sim_zono << "  [" << i << "] ";
          //mettre en  vecteur
          sim_zono << vec[i].center;
          for (auto& c : vec[i].coeffs) {
            if (c.second >= 0) sim_zono << " + " << c.second << "*eps_" << c.first;
            else sim_zono << " - " << -c.second << "*eps_" << c.first;
            if (c.first>num_noise)
            {
              break;
            }
          }
          //sim_zono << " + [" << vec[i].garbage.lb() << ", " << vec[i].garbage.ub() << "]";

          sim_zono << "\n";
      }
    }
      sim_zono.close();
}



double normal_cdf(double x) {
    return 0.5 * (1 + std::erf(x / std::sqrt(2.0)));
}

double gaussian_pdf(double x, double mu, double sigma2)
{
    const double sigma = std::sqrt(sigma2);
    const double coef = 1.0 / (sigma * std::sqrt(2.0 * M_PI));
    const double expo = - ( (x - mu) * (x - mu) ) / (2.0 * sigma2);
    return coef * std::exp(expo);
}


double interval_prob(double a, double b, double mu, double sigma) {
    //std::cout << "P(" << a << " <= X <= " << b << ") " << mu <<" <mu sigma> " << sigma <<endl;
    if (sigma == 0 && a<=mu && b>=mu)
    {
      return 1; ///si sigma ==0 on dit qu'on a un dirac en mu
    }
    else if (sigma == 0)
    {
      return 0;
    }
    
    double z1 = (a - mu) / sigma;
    double z2 = (b - mu) / sigma;
    return normal_cdf(z2) - normal_cdf(z1);
}

bool areEqual(const std::vector<double>& v1, const std::vector<double>& v2) {
    // Vérifie si les tailles sont différentes
    if (v1.size() != v2.size()) {
        return false;
    }

    // Compare chaque élément
    for (size_t i = 0; i < v1.size(); ++i) {
        if (v1[i] != v2[i]) {
            return false;
        }
    }

    return true;
}

// calcule du convexhull en utilisant Qhull (Quick Hull) install: sudo apt-get install qhull-bin libqhull-dev
std::vector<std::vector<double>> computeConvexHullVertices(const std::vector<std::vector<double>>& point_cloud) 
{
    if (point_cloud.empty()) {
        throw std::runtime_error("Point cloud vide !");
    }

    int dim = point_cloud[0].size();
    int numPoints = point_cloud.size();

    for (const auto& p : point_cloud) {
        if ((int)p.size() != dim) {
            throw std::runtime_error("Tous les points doivent avoir la même dimension !");
        }
    }

    // Aplatir le tableau pour Qhull
    std::vector<double> flatPoints;
    flatPoints.reserve(numPoints * dim);
    for (const auto& p : point_cloud) {
        flatPoints.insert(flatPoints.end(), p.begin(), p.end());
    }

    Qhull qh;
    qh.runQhull("convex_hull", dim, numPoints, flatPoints.data(), "Qt");

    // Extraire les sommets
    std::vector<std::vector<double>> hullVertices;
    for (auto v = qh.vertexList().begin(); v != qh.vertexList().end(); ++v) {
        const double* coords = v->point().coordinates();
        hullVertices.emplace_back(coords, coords + dim);
    }

    return hullVertices;
}


void printAffineDecomp(const AffineDecomp& a) {
    std::cout << a.center;
    for (auto& c : a.coeffs) {
        if (c.second >= 0) std::cout << " + " << c.second << "*eps_" << c.first;
        else std::cout << " - " << -c.second << "*eps_" << c.first;
    }
    std::cout << " + [" << a.garbage.lb() << ", " << a.garbage.ub() << "]";
}

void printAffineVector(const Aff2Vec& vec) {
    std::cout << "AffineDecomp vector (" << vec.size() << " elements):\n";
    for (size_t i = 0; i < vec.size(); ++i) {
        std::cout << "  [" << i << "] ";
        printAffineDecomp(vec[i]);
        std::cout << "\n";
    }
}

void print_vertices(std::vector<std::vector<double>>cloud){
for (size_t i = 0; i < cloud.size(); i++)
{
  std::cout<<"vertices "<<i<<" : "<<std::endl;
  for (size_t j = 0; j < cloud[i].size(); j++)
  {
    std::cout<<cloud[i][j]<<" ; ";
  }
  cout<<endl;
}
}

// Fabrique une affine2 avec un centre et des coefficients eps_i pour Ibex avec fAFFullI
Affine2Main<AF_fAFFullI> make_affine(
    double center,
    const std::vector<std::pair<int,double>>& coeffs,
    Interval garbage) 
{
    Affine2Main<AF_fAFFullI> a(center);
    std::list<std::pair<int,double>> rays;
    for (auto& c : coeffs) {
        rays.push_back(c);
    }
    a.initialize(center, rays, garbage);
    return a;
}

// transforme une Affine de dynibex fAFFullI dans mon format
AffineDecomp decompose_affine(const Affine2Main<AF_fAFFullI>& a) {
    AffineDecomp dec;
    dec.center = a.val(0);
    dec.garbage = Interval(-a.err(), a.err()); // l’erreur est centrée

    if (a.is_actif()) {
        for (const auto& r : a.get_rays()) {
            dec.coeffs.push_back({r.first, r.second});
        }
    } else {
        std::cout << "Prog: Affine2Main form not Activate" << std::endl;
    }

    return dec;
}

///on crée la liste des combinaisons possible de générateur
std::vector<std::vector<int>> generate_sign_combinations(int N) {
    std::vector<std::vector<int>> combos;
    int total = 1 << N; // 2^N combinaisons

    combos.reserve(total); 

    for (int mask = 0; mask < total; ++mask) {
        std::vector<int> signs(N);
        for (int j = 0; j < N; ++j) {
            // bit j du mask → signe
            signs[j] = (mask & (1 << j)) ? +1 : -1;
        }
        combos.push_back(signs);
    }
    return combos;
}

//fonction d'addition de vecteur
std::vector<double> add_vector(const std::vector<double>& v1, const std::vector<double>& v2){
  
    std::vector<double> result;
    if (v1.size()!= v2.size())
    {
      std::cout<<"ERROR: WRONG SIZE"<<std::endl;
      return result;
    }

    for (size_t i = 0; i < v1.size(); i++)
    {
      result.push_back(v1[i] + v2[i]);
    }
    
    return result;
}

//fonction de multiplication de vecteur
std::vector<double> gain_vector(const std::vector<double>& v1, const int& K){
  
    std::vector<double> result;
    for (size_t i = 0; i < v1.size(); i++)
    {
      result.push_back(K*v1[i]);
    }
    return result;
}

//fonction de multiplication de vecteur mais en double
std::vector<double> gain_vector_double(const std::vector<double>& v1, const double& K){
  
    std::vector<double> result;
    for (size_t i = 0; i < v1.size(); i++)
    {
      result.push_back(K*v1[i]);
    }
    return result;
}


double dot_vector(const std::vector<double>& a, const std::vector<double>& b) {
    if (a.size() != b.size()) {
        throw std::runtime_error("Dot product: size mismatch");
    }

    double result = 0.0;
    for (size_t i = 0; i < a.size(); ++i) {
        result += a[i] * b[i];
    }
    return result;
}

std::vector<double> element_product(const std::vector<double>& a, const std::vector<double>& b)
{
  
   if (a.size() != b.size()) {
        throw std::runtime_error("element product: size mismatch");
    }
    std::vector<double> result(a.size(), 0.0);
    
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = a[i] * b[i];
    }
    return result;
}

// transforme une vecteur d'Affine de dynibex fAFFullI dans un vecteur de mon format
Aff2Vec DyniAff2Vec(const Affine2Vector& aff_vec){

  Aff2Vec result;

  for (size_t i = 0; i < aff_vec.size(); i++)
  {
    result.push_back(decompose_affine(aff_vec[i]));
  }
    //printAffineVector(result);
  return result;
}

// transforme une vecteur d'Affine de dynibex fAFFullI dans un vecteur de mon format
Aff2Vec Interval2Aff(const IntervalVector& itv_vec){

  //Aff2Vec result;
  Affine2Vector temp(itv_vec, true);
  //for (size_t i = 0; i < itv_vec.size(); i++)
  //{
  //  AffineDecomp temp;
  //  temp.build_aff(itv_vec[i].mid(),{{i,itv_vec[i].diam()/2}});
  //  result.push_back(temp);
  //}
    //printAffineVector(result);
  return DyniAff2Vec(temp);
}


Affine2Vector Aff2VecDyn(const Aff2Vec& aff_vec){ //passer de mon format au format dynibex

  Affine2Vector result(aff_vec.size());

  for (size_t i = 0; i < result.size(); i++)
  {
    result[i] = make_affine(aff_vec[i].center, aff_vec[i].coeffs, aff_vec[i].garbage);
  }
    //printAffineVector(result);
  return result;
}

//on récupère le vecteur du centre d'un vecteur d'affine
std::vector<double> get_center_aff2vec(const Aff2Vec& affine_vector){
  
  std::vector<double> result;
  for (size_t i = 0; i < affine_vector.size(); i++)
  {
    result.push_back(affine_vector[i].center);
  }
  return result;
}

std::vector<std::vector<double>> build_generators(const Aff2Vec& aff_vec) {
    const size_t dim_vec = aff_vec.size();

    std::unordered_set<int> ids_set;
    ids_set.reserve(256);

    for (const auto& a : aff_vec) {
        for (const auto& kv : a.coeffs) {
            ids_set.insert(kv.first);
        }
    }

    std::vector<int> noise_symbols(ids_set.begin(), ids_set.end());
    std::sort(noise_symbols.begin(), noise_symbols.end());

    std::vector<std::vector<double>> generators;
    generators.reserve(noise_symbols.size());

    for (int id : noise_symbols) {
        std::vector<double> g(dim_vec, 0.0);

        for (size_t j = 0; j < dim_vec; ++j) {
            
            for (const auto& c : aff_vec[j].coeffs) {
                if (c.first == id) { g[j] = c.second; break; }
            }
        }

        generators.push_back(std::move(g));
    }

    return generators;
}

// c'est la fonction qui calcule les combinaisons possible de génerateur
PointCloud candidate_vertices(const Aff2Vec& affine_vector){
  
  PointCloud result;
  const double size_vec = affine_vector.size();
  //mettre le centre -fait
  const std::vector<double> center_vec = get_center_aff2vec(affine_vector);
  const std::vector<std::vector<double>> generators = build_generators(affine_vector); //on construit les generateurs
  std::vector<std::vector<int>> combos = generate_sign_combinations(generators.size()); //on construit les combos de vecteurs

  for (size_t i = 0; i < combos.size(); i++)
  {
    std::vector<double> temp(size_vec,0.0);
    for (size_t j = 0; j < combos[i].size(); j++)
    {
      temp = add_vector(gain_vector(generators[j], combos[i][j]), temp);
    }
    auto computed_point = add_vector(temp, center_vec);//on rajoute le centre
    result.cloud.push_back(computed_point);
    result.cloud_origin.push_back(make_pair(computed_point, combos[i]));
  }
    return result;
}

PointCloud Affine2Vertices(const Aff2Vec& aff_vec){
    PointCloud result;

    
    for (size_t i = 0; i < nombre_dimension_plot; i++)
    {
      if (aff_vec[i].coeffs.empty())
      {
        return result; //on calcule pas des nuages de points vide
      }
    }

    PointCloud comp_cl = candidate_vertices(aff_vec);
    result.cloud = computeConvexHullVertices(comp_cl.cloud);

    //on associe les dépendances vis à vis des générateurs
    for (size_t i = 0; i < result.cloud.size(); i++)
    {
      for (size_t j = 0; j < comp_cl.cloud.size(); j++)
      {
         if (areEqual(result.cloud[i],comp_cl.cloud[j]))
         {
          result.cloud_origin.push_back(comp_cl.cloud_origin[j]);
          //cout<<"yes"<<endl;
          break;
         }
      }
    }
    return result;
}


double norm_vec(std::vector<double> vec){
  double result = 0;
  for (size_t i = 0; i < vec.size(); i++)
  {
    result = result + vec[i]*vec[i];
  }
  return sqrt(result);
}

double dist_hull(const Aff2Vec& aff_vec, const std::vector<double>& dir){

  std::vector<double> direct = dir;

  const double normal = norm_vec(dir);

  if (normal != 0) //on va eviter les divisions par 0...
  {
    direct = gain_vector_double(dir, 1/normal); //on normalise la direction
  }

  std::vector<std::vector<double>> generators = build_generators(aff_vec);
  double sum = 0;
  for (size_t i = 0; i < generators.size(); i++)
  {
    double temp = dot_vector(direct, generators[i]);

    if (temp>=0)
    {
      sum = sum + temp;
    }
    else
    {
      sum = sum - temp;
    }
  }
  //cout <<"dist to hull: "<< sum <<endl;
  return sum;
}

//utile pour l'intersection, c'est une somme de minkowsky avec un zono centré en 0
Aff2Vec merge_zono(const Aff2Vec& aff_vec1, const Aff2Vec& aff_vec2){ 

  Aff2Vec result = aff_vec1;

  int max = 0; //nombre de termes de bruits

      // chercher l'indice max de bruit utilisé
      for (const auto& a : aff_vec1) {
          for (auto& kv : a.coeffs) {
              if (kv.first > max){
                max = kv.first;
              }
          }
      }
      for (const auto& a : aff_vec2) {
          for (auto& kv : a.coeffs) {
              if (kv.first > max){
                max = kv.first;
              }
          }
      }
      int j = 0;
      for (AffineDecomp aff : aff_vec2)
      {
        for (size_t i = 0; i < aff.coeffs.size(); i++)
        {
          aff.coeffs[i].first = aff.coeffs[i].first + max;
          result[j].coeffs.push_back(aff.coeffs[i]);
        }
        j++; //on rajoute les autres générateurs
      }  
      
      for (size_t i = 0; i < result.size(); i++)
      {
       result[i].center = 0;
      }

      return result;
}

//en boite, pratique pour mon format de donnée, passer un jour tout en classe / struct
ibex::IntervalVector to_hull(const Aff2Vec& aff_vec){ 

IntervalVector result(aff_vec.size());

  for (size_t i = 0; i < result.size(); i++)
  {
    double temp_max = 0;

    for (size_t j = 0; j < aff_vec[i].coeffs.size(); j++)
    {
        double val = aff_vec[i].coeffs[j].second;
        temp_max = temp_max + std::abs(val); //on calcule le hull du zonotope mais que pour le garbage
    }
    result[i] = Interval(aff_vec[i].center - temp_max , aff_vec[i].center + temp_max); //symétrie d'un zonotope et il prend le centre
  }
return result;
}

//resolution de la faisabilité d'un problème LP
bool is_include(const Aff2Vec& aff_vec, const std::vector<double>& x) 
{

    std::vector<double> c = get_center_aff2vec(aff_vec);      // taille n
    std::vector<std::vector<double>> generators = build_generators(aff_vec); // m générateurs, chacun de taille n
    glp_term_out(GLP_OFF);
    const int n = static_cast<int>(c.size());          // dimension de l'espace
    const int m = static_cast<int>(generators.size()); // nombre de générateurs

    if (x.size() != static_cast<size_t>(n)) {
        std::cerr << "Dimension du point incompatible avec le zonotope\n";
        return false;
    }

    std::vector<double> d(n);
    for (int i = 0; i < n; ++i) {
        d[i] = x[i] - c[i];
    }

    glp_prob* lp = glp_create_prob();
    glp_set_prob_name(lp, "zonotope_membership");
    glp_set_obj_dir(lp, GLP_MIN); // minimisation de 0

    glp_add_cols(lp, m);
    for (int j = 0; j < m; ++j) {
        int col = j + 1;
        glp_set_col_name(lp, col, ("z" + std::to_string(col)).c_str());
        // -1 <= z_j <= 1
        glp_set_col_bnds(lp, col, GLP_DB, -1.0, 1.0);
        // Coût de l'objectif : 0 * z_j
        glp_set_obj_coef(lp, col, 0.0);
    }

    glp_add_rows(lp, n);
    for (int i = 0; i < n; ++i) {
        int row = i + 1;
        glp_set_row_name(lp, row, ("eq" + std::to_string(row)).c_str());
        // contrainte fixée : (Gz)_i = d_i
        glp_set_row_bnds(lp, row, GLP_FX, d[i], d[i]);
    }

    const int nz = n * m;
    std::vector<int> ia(1 + nz);
    std::vector<int> ja(1 + nz);
    std::vector<double> ar(1 + nz);

    int k = 1;
    for (int i = 0; i < n; ++i) {          // ligne
        for (int j = 0; j < m; ++j) {      // colonne
            ia[k] = i + 1;                 // ligne i+1
            ja[k] = j + 1;                 // colonne j+1
            ar[k] = generators[j][i];
            ++k;
        }
    }

    glp_load_matrix(lp, nz, ia.data(), ja.data(), ar.data());

    glp_simplex(lp, nullptr);

    int status = glp_get_status(lp);
    bool inside = false;

    if (status == GLP_OPT || status == GLP_FEAS) {
        inside = true;
        const double tol = 1e-7;

        std::vector<double> z(m);
        for (int j = 0; j < m; ++j) {
            z[j] = glp_get_col_prim(lp, j + 1);
            if (std::fabs(z[j]) > 1.0 + tol) {
                inside = false;
            }
        }

        for (int i = 0; i < n; ++i) {
            double sum = 0.0;
            for (int j = 0; j < m; ++j) {
                sum += generators[j][i] * z[j];
            }
            if (std::fabs(sum - d[i]) > 1e-6) {
                inside = false;
            }
        }
    }

    glp_delete_prob(lp);
    glp_free_env();

    return inside;
}

//mettre programe de test de l'intersection
bool is_intersect(const Aff2Vec& aff_vec1, const Aff2Vec& aff_vec2){
  const std::vector<double> center1 = get_center_aff2vec(aff_vec1);
  const std::vector<double> center2 = get_center_aff2vec(aff_vec2);

  std::vector<double> coord = add_vector(center2, gain_vector(center1, -1));

  return is_include(merge_zono(aff_vec1, aff_vec2), coord);
}

//sous optimal aff1 inclu dans aff2 ?
bool is_subset(const Aff2Vec& aff_vec1, const Aff2Vec& aff_vec2){
  
  if (!is_intersect(aff_vec1,aff_vec2))
  {
    return false; //si l'intersection est vide ça sert à rien de continuer
  }
  PointCloud vertices = Affine2Vertices(aff_vec1);
  //print_vertices(vertices.cloud);
  for (size_t i = 0; i < vertices.cloud.size(); i++)
  {
    //cout <<"---point "<<i<<"---"<<endl;
    if (!is_include(aff_vec2, vertices.cloud[i]))
    {
      //cout<<"point "<<i<<" outside"<<endl;
      return false; // si un point ne lui appartient pas alors il n'est pas inclu
    }
  }
  return true; //tout les sommets sont inclus donc c'est bon, comme l'espace est convexe il existe une droite entre deux points inclu dans l'ensemble et comme tout les sommets sont inclu dedans alors tout les elements de la frontière sont inclu dans le zonotope aff2
} 

bool is_in_list(const std::vector<int>& gen_num, const int& num){
  for (size_t i = 0; i < gen_num.size(); i++)
  {
    if (gen_num[i]==num)
    {
      return true;
    }
  }
  return false;
}

double get_noise_val(std::vector<std::pair<int,double>> coeffs, const int& num){ //pas propre ça devrait être une methode de la struct
    for (size_t i = 0; i < coeffs.size(); i++)
    {
      if (coeffs[i].first==num)
      {
        return coeffs[i].second;
      }
    }
  return 0; //si il n'existe pas alors c'est 0
}

std::vector<double> get_ub(IntervalVector temp){ //je veux juste dans un format vector double et pas Vector comme avec Ibex
  std::vector<double> result;
  for (size_t i = 0; i < temp.size(); i++)
  {
    result.push_back(temp[i].ub());
  }
    return result;  
}

std::vector<double> get_lb(IntervalVector temp){
  std::vector<double> result;
  for (size_t i = 0; i < temp.size(); i++)
  {
    result.push_back(temp[i].lb());
  }
    return result;  
}


IntervalVector garbage_to_box(const std::vector<int>& gen_num, const Aff2Vec& aff_vec){

  IntervalVector result(aff_vec.size());

  for (size_t i = 0; i < result.size(); i++)
  {
    double temp_max = 0;

    for (size_t j = 0; j < aff_vec[i].coeffs.size(); j++)
    {
      if (!is_in_list(gen_num ,aff_vec[i].coeffs[j].first))
      {
        double val = aff_vec[i].coeffs[j].second;
        temp_max = temp_max + std::abs(val); //on calcule le hull du zonotope mais que pour le garbage
      }
    }
    result[i] = Interval(- temp_max ,+ temp_max); //symétrie d'un zonotope et il prend le centre
  }
return result;

}


IntervalVector Pontryagin_diff(IntervalVector vec1, IntervalVector vec2){ //vec1 - vec2
  const int size = vec1.size();

  IntervalVector result(size);
  if (size!=vec2.size())
  {
    cout<<"error: wrong dimension ! (Pontryagin), size 1: "<< vec1.size()<< " size 2: " <<vec2.size();
    //ça arrive quand on perds les dependences localement à cause d'un .compact normal si size 1 est à 0
    return result;
  }
  
  for (size_t i = 0; i < size; i++)
  {
    result[i] = Interval(vec1[i].lb() - vec2[i].lb(), vec1[i].ub()-vec2[i].ub());
  }
  return result;
}

std::pair<std::vector<double>,std::vector<double>> pred_garb_min(const IntervalVector& garbage, const IntervalVector& predicate, const std::vector<double>& offset){

IntervalVector temp = Pontryagin_diff(predicate, garbage);
///on fait la différence de Pontryagin après avoir recentré

  std::vector<double> lb = get_lb(temp);
  std::vector<double> ub = get_ub(temp);

  return {add_vector(lb, gain_vector(offset, -1)) ,add_vector(ub, gain_vector(offset, -1))};
}

///C'est pour le predicat réduit
std::pair<std::vector<double>,std::vector<double>> Aff2Vec_to_Vec(std::vector<int> gen_num, const Aff2Vec& aff_vec, const Aff2Vec& predicate){
return pred_garb_min(garbage_to_box(gen_num, aff_vec), to_hull(predicate), get_center_aff2vec(aff_vec));  
}

///pour la matrice de géné
std::pair<std::vector<vector<double>>, std::vector<vector<double>>> Aff2Vec_to_Mat(std::vector<int> gen_num, const Aff2Vec& aff_vec){
  std::vector<vector<double>> Amax;
  std::vector<vector<double>> Amin;

  for (size_t i = 0; i < aff_vec.size(); i++)
    {
      vector<double> tempV; //max
      vector<double> tempM; //min
      for (size_t j = 0; j < gen_num.size(); j++)
      {
        tempV.push_back(std::abs(get_noise_val(aff_vec[i].coeffs, gen_num[j]))); //on construit les lignes de la matrice Amax puis Amin
        tempM.push_back(-std::abs(get_noise_val(aff_vec[i].coeffs, gen_num[j])));
      }
    Amax.push_back(tempV);
    Amin.push_back(tempM);
    //symétrie d'un zonotope et il prend le centre
    }
    return make_pair(Amin, Amax);
}

std::vector<vector<double>> Aff2Vec_to_Mat_select(std::vector<int> gen_num, const Aff2Vec& aff_vec){
  std::vector<vector<double>> Amax;

  for (size_t i = 0; i < aff_vec.size(); i++)
    {
      vector<double> tempV; //max
      vector<double> tempM; //min
      for (size_t j = 0; j < gen_num.size(); j++)
      {
        tempV.push_back(get_noise_val(aff_vec[i].coeffs, gen_num[j])); //on construit les lignes de la matrice Amax puis Amin
      }
    Amax.push_back(tempV);
    }
    return Amax;
}


std::vector<IntervalVector> constraints_selector(const IntervalVector& predicate, const std::vector<double>& point){

  std::vector<IntervalVector> result;
  for (size_t i = 0; i < predicate.size(); i++)
  {
    if (!predicate[i].contains(point[i]))
    {
      IntervalVector temp(predicate.size(), Interval(-1000, 1000));
      if (point[i]>predicate[i].ub())
      {
        temp[i] = Interval(predicate[i].ub(), 1000);
        result.push_back(temp); ///halspace superieur
      }
      else
      {
        temp[i] = Interval(-1000, predicate[i].lb());
        result.push_back(temp); ///halfspace inferieur
      }
    }
  }
  if (result.empty())
  {
    return{predicate}; //le centre est inclu donc la contrainte est que sur le centre
  }
  
  return result;
} ///faire tout les test et prendre la proba max


std::vector<double> solve_lp_glpk( //à utiliser pour trouver le zonotope optimale
    const std::pair<std::vector<std::vector<double>>, std::vector<std::vector<double>>>& A,
    const std::pair<std::vector<double>, std::vector<double>>& B,
    const std::vector<double>& c, const ibex::IntervalVector& limit)
{
  glp_term_out(GLP_OFF);
    const auto& A1 = A.first;
    const auto& A2 = A.second;
    const auto& b1 = B.first;
    const auto& b2 = B.second;

    const int m1 = static_cast<int>(A1.size());  // nb de lignes A1
    const int m2 = static_cast<int>(A2.size());  // nb de lignes A2

    if (m1 != static_cast<int>(b1.size()) || m2 != static_cast<int>(b2.size())) {
        std::cerr << "Erreur: taille de A1/b1 ou A2/b2 incoherente\n";
        return {};
    }

    if ((m1 > 0 && A1[0].size() != c.size()) ||
        (m2 > 0 && A2[0].size() != c.size())) {
        std::cerr << "Erreur: nb de colonnes de A1/A2 incoherent avec c\n";
        return {};
    }

    const int n = static_cast<int>(c.size());   // dimension de x
    const int m = m1 + m2;                      // nb total de contraintes

    glp_prob* lp = glp_create_prob();
    glp_set_prob_name(lp, "my_lp");
    glp_set_obj_dir(lp, GLP_MAX);  // max c^T x

    glp_add_cols(lp, n);
    for (int j = 0; j < n; ++j) {
        std::string name = "x" + std::to_string(j+1);
        glp_set_col_name(lp, j+1, name.c_str());
        // x_j >= 0
        glp_set_col_bnds(lp, j+1, GLP_DB, limit[j].lb(), limit[j].ub());
        // coût c_j
        glp_set_obj_coef(lp, j+1, c[j]);
    }

    glp_add_rows(lp, m);

    for (int i = 0; i < m2; ++i) {
        std::string name = "A2_" + std::to_string(i+1);
        glp_set_row_name(lp, i+1, name.c_str());
        // a_i^T x <= b2[i]
        glp_set_row_bnds(lp, i+1, GLP_UP, 0.0, b2[i]);
    }

    for (int i = 0; i < m1; ++i) {
        int row = m2 + i + 1;
        std::string name = "A1_" + std::to_string(i+1);
        glp_set_row_name(lp, row, name.c_str());
        // (-A1_i) x <= -b1[i]
        glp_set_row_bnds(lp, row, GLP_UP, 0.0, -b1[i]);
    }

    const int nz = m * n;
    std::vector<int> ia(nz + 1);
    std::vector<int> ja(nz + 1);
    std::vector<double> ar(nz + 1);

    int k = 1;

    for (int i = 0; i < m2; ++i) {
        for (int j = 0; j < n; ++j) {
            ia[k] = i + 1;      // ligne
            ja[k] = j + 1;      // colonne
            ar[k] = A2[i][j];   // coeff
            ++k;
        }
    }

    for (int i = 0; i < m1; ++i) {
        int row = m2 + i + 1;
        for (int j = 0; j < n; ++j) {
            ia[k] = row;
            ja[k] = j + 1;
            ar[k] = -A1[i][j];
            ++k;
        }
    }

    glp_load_matrix(lp, nz, ia.data(), ja.data(), ar.data());

    glp_simplex(lp, nullptr);

    int status = glp_get_status(lp);

    std::vector<double> x;

    if (status == GLP_OPT || status == GLP_FEAS) {
        x.resize(n);
        for (int j = 0; j < n; ++j) {
            x[j] = glp_get_col_prim(lp, j+1);
        }
    } else {
        std::cerr << "LP infeasible ou non resolu, status = " << status << "\n";
    }

    glp_delete_prob(lp);

    return x;
}


std::vector<double> Inclusion_LP(const std::vector<double>& coeff_fct, const Aff2Vec& state, const Aff2Vec& predicate, const std::vector<int>& genenum, const ibex::IntervalVector& limit){

  return solve_lp_glpk(Aff2Vec_to_Mat(genenum, state), Aff2Vec_to_Vec(genenum,state, predicate),coeff_fct, limit);
}

std::vector<double> solve_multi_lp(
    const std::vector<ItvMatrix>& Mats,   // liste des (Amin, Amax)
    const std::vector<ItvVector>& Vecs,   // liste des (bmin, bmax)
    const std::vector<double>& c,
    const ibex::IntervalVector& limit)
{
  glp_term_out(GLP_OFF); //on coupe la sortie

    if (Mats.size() != Vecs.size()) {
        std::cerr << "Erreur: Mats.size() != Vecs.size()\n";
        return {};
    }

    const int nb_blocks = static_cast<int>(Mats.size());
    const int n = static_cast<int>(c.size());  // dimension de x

    int total_m1 = 0;
    int total_m2 = 0;

    for (int k = 0; k < nb_blocks; ++k) {
        const auto& A1 = Mats[k].first;   // Amin
        const auto& A2 = Mats[k].second;  // Amax
        const auto& b1 = Vecs[k].first;   // bmin
        const auto& b2 = Vecs[k].second;  // bmax

        int m1 = static_cast<int>(A1.size());
        int m2 = static_cast<int>(A2.size());

        if (m1 != static_cast<int>(b1.size()) ||
            m2 != static_cast<int>(b2.size())) {
            std::cerr << "Erreur: taille de A1/b1 ou A2/b2 incoherente pour le bloc " << k << "\n";
            return {};
        }

        if ((m1 > 0 && static_cast<int>(A1[0].size()) != n) ||
            (m2 > 0 && static_cast<int>(A2[0].size()) != n)) {
            std::cerr << "Erreur: nb de colonnes de A1/A2 incoherent avec c pour le bloc " << k << "\n";
            return {};
        }

        total_m1 += m1;
        total_m2 += m2;
    }

    const int m = total_m1 + total_m2; // nb total de contraintes

    glp_prob* lp = glp_create_prob();
    glp_set_prob_name(lp, "my_multi_lp");
    glp_set_obj_dir(lp, GLP_MAX);  // max c^T x

    glp_add_cols(lp, n);
    for (int j = 0; j < n; ++j) {
        std::string name = "x" + std::to_string(j+1);
        glp_set_col_name(lp, j+1, name.c_str());
        glp_set_col_bnds(lp, j+1, GLP_DB, limit[j].lb(), limit[j].ub());
        glp_set_obj_coef(lp, j+1, c[j]);
    }

    glp_add_rows(lp, m);

    {
        int row_offset_m2 = 0;
        for (int k = 0; k < nb_blocks; ++k) {
            const auto& A2 = Mats[k].second;
            const auto& b2 = Vecs[k].second;
            int m2 = static_cast<int>(A2.size());

            for (int i = 0; i < m2; ++i) {
                int row = row_offset_m2 + i + 1;
                std::string name = "A2_block" + std::to_string(k) + "_" + std::to_string(i+1);
                glp_set_row_name(lp, row, name.c_str());
                glp_set_row_bnds(lp, row, GLP_UP, 0.0, b2[i]); // a_i^T x <= b2[i]
            }

            row_offset_m2 += m2;
        }
    }

    {
        int row_offset_m1 = 0;
        for (int k = 0; k < nb_blocks; ++k) {
            const auto& A1 = Mats[k].first;
            const auto& b1 = Vecs[k].first;
            int m1 = static_cast<int>(A1.size());

            for (int i = 0; i < m1; ++i) {
                int row = total_m2 + row_offset_m1 + i + 1;
                std::string name = "A1_block" + std::to_string(k) + "_" + std::to_string(i+1);
                glp_set_row_name(lp, row, name.c_str());
                glp_set_row_bnds(lp, row, GLP_UP, 0.0, -b1[i]); // (-A1_i) x <= -b1[i]
            }

            row_offset_m1 += m1;
        }
    }

    const int nz = m * n;
    std::vector<int> ia(nz + 1);
    std::vector<int> ja(nz + 1);
    std::vector<double> ar(nz + 1);

    int k_nz = 1;

    // Coeffs pour A2
    {
        int row_offset_m2 = 0;
        for (int k = 0; k < nb_blocks; ++k) {
            const auto& A2 = Mats[k].second;
            int m2 = static_cast<int>(A2.size());

            for (int i = 0; i < m2; ++i) {
                int row = row_offset_m2 + i + 1;
                for (int j = 0; j < n; ++j) {
                    ia[k_nz] = row;
                    ja[k_nz] = j + 1;
                    ar[k_nz] = A2[i][j];
                    ++k_nz;
                }
            }
            row_offset_m2 += m2;
        }
    }

    // Coeffs pour -A1
    {
        int row_offset_m1 = 0;
        for (int k = 0; k < nb_blocks; ++k) {
            const auto& A1 = Mats[k].first;
            int m1 = static_cast<int>(A1.size());

            for (int i = 0; i < m1; ++i) {
                int row = total_m2 + row_offset_m1 + i + 1;
                for (int j = 0; j < n; ++j) {
                    ia[k_nz] = row;
                    ja[k_nz] = j + 1;
                    ar[k_nz] = -A1[i][j]; // -A1
                    ++k_nz;
                }
            }
            row_offset_m1 += m1;
        }
    }

    if (nz > 0)
        glp_load_matrix(lp, nz, ia.data(), ja.data(), ar.data());

    glp_simplex(lp, nullptr);
    int status = glp_get_status(lp);

    std::vector<double> x;
    if (status == GLP_OPT || status == GLP_FEAS) {
        x.resize(n);
        for (int j = 0; j < n; ++j) {
            x[j] = glp_get_col_prim(lp, j+1);
        }
    } else {
        std::cerr << "LP infeasible ou non resolu, status = " << status << "\n";
    }

    glp_delete_prob(lp);
    return x;
}


int predicate_no(const int& marker, const int& init_marker){
  int result = marker - marker%init_marker;
  return result/init_marker;
}

Aff2Vec Predicate_constraints(const Aff2Vec& state, const Aff2Vec& predicate, const proba_space& param, const vector<double> xsigma)
{

  std::vector<IntervalVector> excl_predicate = constraints_selector(to_hull(predicate), get_center_aff2vec(state));//maintenant mettre le selecteur
  //mettre fonction qui te donne le Pmax
  Aff2Vec result;
  double proba_max = 0;
  if (excl_predicate.size()==1)
  {
    //cout<<"only one option"<<endl;
    return Interval2Aff(excl_predicate[0]);
  }
  
  for (size_t i = 0; i < excl_predicate.size(); i++)
  {
    Aff2Vec temp_predicate = Interval2Aff(excl_predicate[i]);
    //cout<< excl_predicate[i]<<endl;
    //const std::vector<double> xsigma(param.size(),3.0);
    std::vector<double> res;
    for (size_t i = 0; i < param.size(); i++)
    {
      res.push_back(1.0);
    }
    
    IntervalVector limit_pb(param.size());

    for (size_t i = 0; i < param.size(); i++)
    {
      limit_pb[i] = Interval(0.05, 1.2); //modifier les bornes en perso
    }
    ////tout passer en instantiable!!!!
    double delta = 0.1;
    double proba_min = 0;
    double old_proba = 0;

    int counter = 0;

    while (delta > 0.01) ///successive convexification
      {
        counter++;
        std::vector<int> genenum = NumGen_generator(param);
        std::vector<double> coeff_fct =  Coeff_generator(param, res, xsigma);   
        res = Inclusion_LP(coeff_fct, state, temp_predicate, genenum, limit_pb); //test de l'optim

        if (res.empty())
        {
          //cout<<"no solution please redo sim"<<endl;
          break;
        }
        
        old_proba = proba_min;
        proba_min = 1; //instancier ça: fait
        for (size_t i = 0; i < res.size(); i++)
        {
          limit_pb[i] = Interval(std::max(0.05,res[i]-2*delta), std::min(res[i]+2*delta, 1.2)); //modifier les bornes en perso
          proba_min =interval_prob(-xsigma[i]*res[i]*param[i].sigma,xsigma[i]*res[i]*param[i].sigma,0,param[i].sigma)*proba_min;
        }
        
        if (proba_min >= old_proba)
        {
          delta = delta*0.7;
          //cout<< counter <<"-----constraints selection loop-----"<< i <<" proba "<<proba_min <<endl;
        }
      }
    if (old_proba>proba_max)
    {
      result = temp_predicate; //on prend la contrainte la plus relacher puisque après il n'y a que des conjonctions
      proba_max = old_proba;
    }
  }
  //cout<<"proba selection: "<< proba_max<<endl;
  //printAffineVector(result);
  return result;
}


std::vector<double> Multi_Inclusion_LP(const std::vector<double>& coeff_fct, const ZonoTube& tube, const std::vector<Aff2Vec>& predicates, const std::vector<int>& genenum, const ibex::IntervalVector& limit, const std::vector<int>& markers, const int& init_marker, const proba_space& param, const vector<double>& scaling){
 std::vector<ItvMatrix> Mats;
 std::vector<ItvVector> Vecs;

 for (size_t i = 0; i < markers.size(); i++)
 {
    Affine2Vector stateaff = tube.aff[markers[i]%init_marker];
    AF_fAFFullI::setAffineNoiseNumber(n_reduction_zonotope); ///changer pour la compaction sinon trop long au calcul
    stateaff.compact();
    Aff2Vec state = DyniAff2Vec(stateaff);
    Aff2Vec pred = Predicate_constraints(state, predicates[predicate_no(markers[i], init_marker)], param, scaling);

  Mats.push_back(Aff2Vec_to_Mat(genenum, state));
  Vecs.push_back(Aff2Vec_to_Vec(genenum,state, pred));
  //mettre une condition sur le prédicat en fonction du marqueur
 }
 //rajouter le selecteur de contraintes max

  return solve_multi_lp(Mats, Vecs,coeff_fct, limit);

}



std::vector<double> Coeff_generator(const proba_space& space, const std::vector<double>& point, const vector<double>& x_sigma){
  std::vector<double> result;

  for (size_t i = 0; i < point.size(); i++)
  {
    double temp_grad=1;
    for (size_t j = 0; j < space.size(); j++)
    {
      if (i!=j)
      {
        temp_grad = temp_grad*interval_prob(space[j].mu- x_sigma[j]*point[j]*space[j].sigma, space[j].mu+ x_sigma[j]*point[j]*space[j].sigma ,space[j].mu,space[j].sigma);
      }
      else
      {
        temp_grad = temp_grad*gaussian_pdf(space[j].mu + x_sigma[j]*point[j]*space[j].sigma,space[j].mu,space[j].sigma);
      }
    }
    result.push_back(temp_grad);
  }
  return result;
}

std::vector<int> NumGen_generator(proba_space space){
  std::vector<int> result;

  for (size_t i = 0; i < space.size(); i++)
  {
    result.push_back(space[i].num_gen);
    //cout<<space[i].num_gen<<endl;
  }
  return result;
}


Aff2Vec gene_gain(const Aff2Vec& aff_vec,
                  const std::vector<std::pair<int, double>>& selection)
{
    std::unordered_map<int, double> gain_by_gen;
    gain_by_gen.reserve(selection.size());
    for (const auto& p : selection) {
        // si un même générateur apparaît plusieurs fois, le dernier l’emporte
        gain_by_gen[p.first] = p.second;
    }

    Aff2Vec result;
    result.reserve(aff_vec.size());

    for (const auto& aff : aff_vec) {
        AffineDecomp tmp = aff; // copie

        for (auto& coeff : tmp.coeffs) {
            auto it = gain_by_gen.find(coeff.first);
            if (it != gain_by_gen.end()) {
                // multiplier la valeur par le gain associé à ce générateur
                coeff.second *= it->second;
            }
        }

        result.push_back(std::move(tmp));
    }

    return result;
}

ZonoTube tube_gene_gain(const ZonoTube& tube, const std::vector<std::pair<int, double>>& selection, const int& noise_num){

  ZonoTube result = tube;
  for (size_t i = 0; i < tube.time.size(); i++)
  {
    Affine2Vector stateaff = tube.aff[i];
    AF_fAFFullI::setAffineNoiseNumber(noise_num); ///changer pour la compaction sinon trop long au calcul
    stateaff.compact();
    Aff2Vec state = gene_gain(DyniAff2Vec(stateaff), selection);

    result.aff[i]= Aff2VecDyn(state);
    result.zono[i]= state;
  }
  
  return result;
}

Aff2Vec IntervalVector_to_Aff(ibex::IntervalVector itv_vec){ ///inutile puisque Interval2Aff le fait sans erreur memoire
Aff2Vec result;

for (size_t i = 0; i < itv_vec.size(); i++)
{
  AffineDecomp temp_aff;
  temp_aff.build_aff(itv_vec[i].mid(),{make_pair(i,itv_vec[i].diam()/2)});
  result.push_back(temp_aff);
}
return result;
}

//obligatoirement dans un ordre croissant et à la suite 1,2,3,4 ...
std::vector<std::pair<int, double>> reduction_to_selection(std::vector<double> reduction_liste){
  std::vector<std::pair<int, double>> result;

  for (size_t i = 0; i < reduction_liste.size(); i++)
  {
    result.push_back({i+1, reduction_liste[i]});
  }
  return result;
}



std::vector<int> merge_vectors(const std::vector<int>& a,
                               const std::vector<int>& b)
{
    std::vector<int> result;
    result.reserve(a.size() + b.size());  // évite les reallocations

    result.insert(result.end(), a.begin(), a.end());
    result.insert(result.end(), b.begin(), b.end());

    return result;
}

std::pair<std::vector<std::vector<int>>,std::vector<int>> markers_compactator(const std::vector<int>& list, const int& groupesize){
  std::vector<int> list_markers = negatif_cleaner(list);
  std::vector<std::vector<int>> decompact;
  std::vector<int> indexlist;
  int counter = 0;

  for (int i = 0; i < list_markers.size(); i++)
  {  
    int iter = 0;
    std::vector<int> associated;
    for (int j = 0; j < groupesize; j++)
    {
      if (list_markers[i]-(j)==list_markers[i+(j)]&&i+j<list_markers.size()) //linéarité avec le tri
      {
        associated.push_back(list_markers[i+(j)]);
        //cout<<"---------------continuité--------------"<<endl;
      }
      else
      {
        //cout<<"---------------discontinuité--------------"<<endl;
        break; //on a une discontinuité dans l'échantillonage en temps on skip
      }
     iter = j; 
    }
    decompact.push_back(associated);
    i += iter;
    indexlist.push_back(counter);
    counter++;
  }

return {decompact, indexlist};
}

std::vector<std::vector<int>> markers_decompactator(const std::pair<std::vector<std::vector<int>>,std::vector<int>>& input, const std::vector<std::vector<int>>& compact_combos){

  std::vector<std::vector<int>>result;

  for (size_t i = 0; i < compact_combos.size(); i++)
  {
    std::vector<int> current_combos = compact_combos[i];
    std::vector<int> new_combos;

    for (size_t j = 0; j < current_combos.size(); j++)
    {
      for (size_t k = 0; k < input.first[current_combos[j]].size(); k++)
      {
        new_combos.push_back(input.first[current_combos[j]][k]);
      }      
    }
    result.push_back(new_combos);
  }
  return result;
}

std::vector<int> marker_temporal_cleaner(const ZonoTube& tube, const double& t, const std::vector<int>& init_list, const std::vector<Interval>& predicate_horizon, const int& tube_len){

  std::vector<int> result;
  Interval time = Interval(t);
  ///c'est une fonction pour enlever les surapproximations temporelles

  for (size_t i = 0; i < init_list.size(); i++)
  {
    Interval reach_time = tube.time[init_list[i]%tube_len];
    Interval subformulahorizon = time + predicate_horizon[predicate_no(init_list[i], tube_len)];
    if (reach_time.intersects(subformulahorizon))
    {
      result.push_back(init_list[i]);
    }
  }

  return result;
}



std::pair<double, std::vector<double>> parameter_set_STL(ZonoTube tube, proba_space param, const std::vector<Aff2Vec>& predicates, const std::vector<int>& markers, const std::vector<double>& xsigma , const double& criterion , const bool& trigger ,const int& init_marker = 1000){

    //const std::vector<double> xsigma(param.size(),3.0); //changer là
    double lower_bound = 1 - criterion*0.95;

    std::vector<double> res;
    std::vector<double> resultat;
    for (size_t i = 0; i < param.size(); i++)
    {
      res.push_back(1.0);
    }

    double upper_bound = 1.2;
    if (trigger)
    {
      upper_bound = 0.96; //on force la monotonie d'inclusion et on downshoot un peu MODIFIABLE
      lower_bound = lower_bound - 0.04; // pour preserver l'encadrement MODIFIABLE 1-upper_bound
    }

    IntervalVector limit_pb(param.size());
    for (size_t i = 0; i < param.size(); i++)
    {
      limit_pb[i] = Interval(lower_bound, upper_bound); //modifier les bornes en perso, preserve l'inclusion
    }
    ////tout passer en instantiable!!!!
    double delta = 0.1;
    double proba_min = 0;
    double old_proba = 0;

    int counter = 0;
    while (delta > 0.005) ///successive convexification
    {
      counter++;
      std::vector<int> genenum = NumGen_generator(param);
      std::vector<double> coeff_fct =  Coeff_generator(param, res, xsigma);  

      //cout<< coeff_fct[0] <<" coeff gene "<< coeff_fct[1]<<  endl;  
      res = Multi_Inclusion_LP(coeff_fct, tube, predicates, genenum, limit_pb, markers, init_marker, param, element_product(res, xsigma)); //test de l'optim

      if (res.empty())
      {
        cout<<"no solution next marker"<<endl;
        break;
      }

      old_proba = proba_min;
      proba_min = 1; //instancier ça: fait
      for (size_t i = 0; i < res.size(); i++)
      {
        limit_pb[i] = Interval(std::max(lower_bound,res[i]-2*delta), std::min(res[i]+2*delta,upper_bound)); //modifier les bornes en perso
        proba_min =interval_prob(-xsigma[i]*res[i]*param[i].sigma,xsigma[i]*res[i]*param[i].sigma,0,param[i].sigma)*proba_min;
      }
      
      if (proba_min >= old_proba)
      {
        delta = delta*0.7;
        //cout<<"---------------dividing----------------"<<endl;
      }

      //cout<<proba_min<<endl;
    }
    
    if (!res.empty())
    {
      resultat = element_product(res, xsigma);//nouveau coeff devant la variance
      cout<< res[0] <<" coeff reduc "<< res[1]<<endl;
    }
    
    //print_zonotube_to_file(tube,5);
    //print_vertices_to_file(tube,5);
    return {old_proba, resultat};
}



std::pair<double, std::vector<double>> parameter_set_STL_r(ZonoTube tube, proba_space param, const std::vector<Aff2Vec>& predicates, const std::vector<int>& markers, const std::vector<double>& xsigma , const double& criterion ,const int& init_marker = 1000){

    //const std::vector<double> xsigma(param.size(),3.0); //changer là
    const double upper_bound = 1 + criterion*0.4;
    std::vector<double> res;
    std::vector<double> resultat;
    for (size_t i = 0; i < param.size(); i++)
    {
      res.push_back(1.0);
    }

    IntervalVector limit_pb(param.size());
    for (size_t i = 0; i < param.size(); i++)
    {
      limit_pb[i] = Interval(0.8, upper_bound); //modifier les bornes en perso
    }
    ////tout passer en instantiable!!!!
    double delta = 0.05;
    double proba_min = 0.0;
    double old_proba = 0.0;

    int counter = 0;
    while (delta > 0.005) ///successive convexification
    {
      counter++;
      std::vector<int> genenum = NumGen_generator(param);
      std::vector<double> coeff_fct =  Coeff_generator(param, res, xsigma);  

      //cout<< coeff_fct[0] <<" coeff gene "<< coeff_fct[1]<<  endl;  
      res = Multi_Inclusion_LP(coeff_fct, tube, predicates, genenum, limit_pb, markers, init_marker, param, element_product(res, xsigma)); //test de l'optim

      if (res.empty())
      {
        cout<<"no solution for robustness"<<endl;
        break;
      }
      else
      {
        //auto new_aff = gene_gain(tube.zono[94],{{1,res[0]},{2,res[1]}});
        //tube.aff.push_back(Aff2VecDyn(new_aff));
        //tube.zono.push_back(new_aff);
      }

      old_proba = proba_min;
      proba_min = 1; //instancier ça: fait
      for (size_t i = 0; i < res.size(); i++)
      {
        limit_pb[i] = Interval(max(0.8,res[i]-2*delta), std::min(res[i]+2*delta, upper_bound)); //modifier les bornes en perso
        proba_min =interval_prob(-xsigma[i]*res[i]*param[i].sigma,xsigma[i]*res[i]*param[i].sigma,0,param[i].sigma)*proba_min;
      }
      
      if (proba_min >= old_proba)
      {
        delta = delta*0.7;
        //cout<<"---------------dividing----------------"<<endl;
      }

      //cout<<proba_min<<endl;
    }
    
    if (!res.empty())
    {
      resultat = element_product(res, xsigma);//nouveau coeff devant la variance
      cout<< res[0] <<" coeff reduc "<< res[1]<<endl;
      cout<<"PROBABILITE "<<old_proba<<endl;
    }
    
    //print_zonotube_to_file(tube,5);
    //print_vertices_to_file(tube,5);
    return {old_proba, resultat};
}


std::pair<double, std::vector<double>> get_optimal_scaling_vector(const ZonoTube& tube, const double& time, const std::vector<Aff2Vec>& predicate_liste, const std::vector<Interval>& predicate_horizon,const proba_space& param, const std::vector<double>& xsigma , const double& criterion, const bool& trigger ,const int& tube_len){

  std::vector<vector<int>> result_final; ///liste de Uplet ou Uplet ou Uplet. chaque uplet à pour contrainte ET
  std::vector<int> invariant;

  std::vector<double> optimal_scaling;

///====================Initialisation=====================
  Satisfaction_Signal Phi;
  std::vector<Satisfaction_Signal> predicate_signals;
  for (size_t i = 0; i < predicate_liste.size(); i++)
  {
    //cout<<"-----------predicate-----------"<<i<<endl;
    Satisfaction_Signal tempsign = predicate_satisfaction_tracking(tube, predicate_liste[i], tube_len*i);
    
    predicate_signals.push_back(tempsign);
  }
   
  Phi = STL_formula(predicate_signals);
  int value = satisfies_at_time(time, Phi);
  if (std::abs(value) !=2)
  {
    cout<<"(!) Formula satisfaction guaranteed (!)"<< value <<endl;
    return {};
  }
  
  std::vector<int> temp = get_uncertainty_marks_at_t(Phi, time);
  cout<<"++++++++++++++++++++initial temp size: "<< temp.size() << endl;
  //print_markers(temp);
  temp = marker_temporal_cleaner(tube, time, temp, predicate_horizon, tube_len);
  cout<<"++++++++++++++++++++filtered temp size: "<< temp.size() << endl;
  print_markers(temp);

  //temp_proba = Markers_and_proba(tube, param, predicate_liste, temp, tube_len)

  std::vector<Satisfaction_Signal> predicate_signals_init; //la copie qui nous servira à calculer one shot les LPs

  for (size_t i = 0; i < predicate_liste.size(); i++)
  {
    Satisfaction_Signal temp_pred = predicate_satisfaction_center(tube, predicate_liste[i], predicate_signals[i], temp, tube_len); // pour tout les predicats pouvant causer de l'incertitude on les mitige tous
    predicate_signals_init.push_back(temp_pred);
  }
  
  cout<<"=========================entering research loop========================="<<endl;


  int compaction = 1;
  std::pair<std::vector<std::vector<int>>,std::vector<int>> compact_marker = markers_compactator(temp, compaction);

  double max_proba = 0.0;

  bool first_iter = true;

  while (compaction>0) 
  {
    std::vector<vector<int>> result;
    std::vector<vector<int>> invariant_uplets;

    int iter = 0;
    
    while (temp.size()>0 && iter<=compact_marker.second.size()) //temps que le uplets est pas plus grand que la taille de la liste à vérifier// mettre temp.size()
      {
        iter++;
        cout<<"=================================== iter : "<<iter<<"==========================================="<<endl;
        
        compact_marker = markers_compactator(temp, compaction);
        
        std::vector<std::vector<int>> uplets = all_k_uplets(compact_marker.second, iter);
        uplets = markers_decompactator(compact_marker, uplets);

        std::vector<int> mitigation = {};

      ///====================Boucle de recherche==================
        for (size_t i = 0; i < uplets.size(); i++)
        {
          std::vector<int> marklist;
          std::vector<Satisfaction_Signal> predicate_signals_iter;
          
          for (size_t j = 0; j < predicate_signals.size(); j++)
          {
            Satisfaction_Signal temp_pred_iter = predicate_satisfaction_oneshot(predicate_signals_init[j], predicate_signals[j], uplets[i], tube_len);
            predicate_signals_iter.push_back(temp_pred_iter);
          }

          Phi = STL_formula(predicate_signals_iter);
          
          value = satisfies_at_time(time, Phi);
          if (value != 2)
          {
            result.push_back(uplets[i]);

            cout<<"======variant======";
            print_markers(uplets[i]);
            auto current_scaling = parameter_set_STL(tube, param, predicate_liste, uplets[i], xsigma , criterion, trigger ,tube_len);
            if (max_proba < current_scaling.first)
            {
              max_proba = current_scaling.first;
              cout<< max_proba<<endl;
              optimal_scaling = current_scaling.second;
            }
            
          }
          else
          {
            //cout<<"------invariant------";
            //print_markers(uplets[i]);
            invariant_uplets.push_back(uplets[i]);
            
            if (first_iter)
            {
              mitigation = merge_vectors(mitigation, get_uncertainty_marks_at_t(Phi, time)); //on fusionne toute les marques qui reste dans les incertitudes contributrices
            }
          }
        }

        int tempsize = temp.size();

        if (first_iter)
        {
          mitigation = negatif_cleaner(mitigation);
          temp = variant_uplet(mitigation, result); //on update ceux sans influence pour chercher si dans le uplet n+1 c'est bon
          first_iter = false;
        }
        else
        {
          temp = variant_uplet(temp, result); //on update ceux sans influence pour chercher si dans le uplet n+1 c'est bon
        }
        //Trie par la probabilité:
        
        std::vector<vector<int>> temporary_invariant;

        for (size_t i = 0; i < invariant_uplets.size(); i++)
        {
          auto current_scaling = parameter_set_STL(tube, param, predicate_liste, invariant_uplets[i],xsigma, criterion, trigger,tube_len);
            if (max_proba > current_scaling.first)
            {
            temporary_invariant.push_back(invariant_uplets[i]);
            }
        }
        temp = variant_uplet(temp, temporary_invariant); //on degage les variants inutiles
        //break;
        cout<<"TAILLE DE LA NOUVELLE LISTE VS ANCIENNE "<<temp.size()<<" VS "<<tempsize<<endl;
      }

    if (result.empty())
    {
      cout<<"!!no solution for DNF!!"<<endl;
      return {max_proba, optimal_scaling};
    } /////on cherche les blocs changeant la satisfaction
    else
    {
      temp = uplet_to_list(result); //on applati pour refaire une recherche après avoir trier les inutiles
    }
    compaction = compaction - 2;
    result_final = result;
    cout<<"=================================== Conquer ==========================================="<<endl;
    print_markers(temp);
  }

/*  
    print_TimeIntervals(Phi);
*/
    return {max_proba, optimal_scaling};
}

std::pair<double, std::vector<double>> get_overshoot_scaling_vector(const ZonoTube& tube, const double& time, const std::vector<Aff2Vec>& predicate_liste,const proba_space& param, const std::vector<double>& xsigma, const double& criterion ,const int& tube_len){

  int weak_index = get_minimal_reachable_set(tube, time, predicate_liste, tube_len);
  
  if (weak_index == -1)
  {
    cout<<"Over-approximation KickBack"<<endl;
    auto result = gain_vector_double(xsigma, 1.1); //when the overaproximation is due to the hyperplane consideration we force a kickback in uncertainty tracking
    return {0.0, result};
  }
  
  cout<<"marker robustness = "<<weak_index<<endl;
  return parameter_set_STL_r(tube, param, predicate_liste, {weak_index}, xsigma ,criterion,tube_len);
}

//=====================STL=================


Satisfaction_Signal predicate_satisfaction_center(const ZonoTube& tube, const Aff2Vec& pset, const Satisfaction_Signal& origine ,const vector<int>& num, const int& init_marker){
  Satisfaction_Signal result = origine;

  for (size_t i = 0; i < num.size(); i++)
  {
    //Satisfaction_Signal temp;
    if (is_include(pset, get_center_aff2vec(tube.zono[num[i]%init_marker])))
    {
        result[num[i]%init_marker].first.first = 1; //le tube n'est pas encore en booléen unitaire donc on a juste à manipuler qu'une valeurs
        result[num[i]%init_marker].first.second = {-1};
    }
    else
    {
      result[num[i]%init_marker].first.first = 0;
      result[num[i]%init_marker].first.second = {-1};
    }
  } 
  return result;
}


Satisfaction_Signal predicate_satisfaction_tr(const ZonoTube& tube, const Aff2Vec& pset){
  //std::vector<TimeInterval> result;
  Satisfaction_Signal P_satisf;

  for (int i = 0; i < tube.time.size(); i++)
  { 
    int val = predicate_test(tube.zono[i],pset);
    if (val != 2)
    {
      P_satisf.push_back({{val,{-1}},{tube.time[i].lb(),tube.time[i].ub()}});
    }
    else
    {
      P_satisf.push_back({{val,{i}},{tube.time[i].lb(),tube.time[i].ub()}}); //on met l'index dans le tube qui provoque l'incertitude
    }
    //result.push_back({val, {tube.time[i].lb(),tube.time[i].ub()}});
  }
  return P_satisf;
}


Satisfaction_Signal predicate_satisfaction_tracking(const ZonoTube& tube, const Aff2Vec& pset, const int& init_marker){
  //std::vector<TimeInterval> result;
  Satisfaction_Signal P_satisf;

  for (int i = 0; i < tube.time.size(); i++)
  { 
    int val = predicate_test_jn(tube.jn[i],to_hull(pset));
    if (val == 2)
    {
      val = predicate_test(tube.zono[i],pset); ///c'est couteux en calcul
    }
    
    if (val != 2)
    {
      P_satisf.push_back({{val,{-1}},{tube.time[i].lb(),tube.time[i].ub()}});
    }
    else
    {
      P_satisf.push_back({{val,{i+init_marker}},{tube.time[i].lb(),tube.time[i].ub()}}); //on met l'index dans le tube qui provoque l'incertitude
    }
    //result.push_back({val, {tube.time[i].lb(),tube.time[i].ub()}});
  }
  return P_satisf;
}


int predicate_test(const Aff2Vec& aff_vec1, const Aff2Vec& aff_vec2){

  if (!is_intersect(aff_vec1,aff_vec2))
  {
    return 0; //si l'intersection est vide ça sert à rien de continuer
  }
  PointCloud vertices = Affine2Vertices(aff_vec1);
  //print_vertices(vertices.cloud);
  for (size_t i = 0; i < vertices.cloud.size(); i++)
  {
    //cout <<"---point "<<i<<"---"<<endl;
    if (!is_include(aff_vec2, vertices.cloud[i]))
    {
      //cout<<"point "<<i<<" outside"<<endl;
      return 2; // si un point ne lui appartient pas alors il n'est pas inclu
    }
  }
  return 1; //tout les sommets sont inclus donc c'est bon, comme l'espace est convexe il existe une droite entre deux points inclu dans l'ensemble et comme tout les sommets sont inclu dedans alors tout les elements de la frontière sont inclu dans le zonotope aff2
}

//===============STL ROBUSTNESS==================

//version avec les formes affines
std::vector<Robust_Signal> predicate_robust(const ZonoTube& tube, const std::vector<Aff2Vec>& predicate_liste) {

    std::vector<Robust_Signal> result;
    double p_val = 0;
    for (size_t j = 0; j < predicate_liste.size(); j++)
    {
        ibex::IntervalVector predicate = to_hull(predicate_liste[j]); //on passe en boite
        Robust_Signal P_satisf;

            for (size_t i = 0; i < tube.jn.size(); i++)
            {
            if (tube.jn[i].is_subset(predicate))
            {
                p_val = distance_min_IntervalVector(tube.jn[i],predicate);
            }
            else if (tube.jn[i].intersects(predicate))
            {
                p_val = 0;
            }
            else
            {
                //excluded
                p_val = -distance_min_euclid_IntervalVector(tube.jn[i], predicate);
            }
                P_satisf.push_back({p_val,{tube.time[i].lb(), tube.time[i].ub()}});
            }
        
        result.push_back(P_satisf);
    }

  return result;
}


int get_minimal_reachable_set(const ZonoTube& tube, const double& time, const std::vector<Aff2Vec>& predicate_liste, const int& tube_len){

    std::vector<Robust_Signal> predicate_robust_signal = predicate_robust(tube, predicate_liste);
    Robust_Signal out_signal = STL_formula_robust(predicate_robust_signal);
    
    int result = -1;
    double mini_robustness = robustness_at_t(out_signal, time);
    if (std::abs(mini_robustness)==0)
    {
        cout<<"uncertainty from robustness: ERR"<<endl;
        return result;
    }
    
    cout<<"robustness mini = "<<mini_robustness<<endl;
    for (size_t i = 0; i < predicate_robust_signal.size(); i++)
    {
        for (size_t j = 0; j < predicate_robust_signal[i].size(); j++)
        {
            if (mini_robustness == predicate_robust_signal[i][j].first)
            {
                result = j + i*tube_len; //on a donc l'index et le numero de predicat
                break;
            }
        }
    }
    return result;
}
