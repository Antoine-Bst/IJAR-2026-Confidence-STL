#ifndef CSTL_Robust_H
#define CSTL_Robust_H

#include <iostream>
#include <vector>
#include <algorithm>
#include <unordered_set>
#include <fstream>
#include "ibex.h"
#include "CSTL.h"
#include "ZonoIbex.h"

using namespace std;
using namespace ibex;

typedef pair<double, pair<double, double>> RobustInterval;
typedef vector<RobustInterval> Robust_Signal;


// Function prototypes
Robust_Signal neg_stl_robust(const Robust_Signal& sp);
Robust_Signal and_stl_robust(const Robust_Signal& sp1, const Robust_Signal& sp2);
Robust_Signal or_stl_robust(const Robust_Signal& sp1, const Robust_Signal& sp2);
void print_RobustIntervals(const Robust_Signal& TimeIntervals);
Robust_Signal Until_robust_titv(const Robust_Signal& sp1, const Robust_Signal& sp2, const pair<double, double>& interval);
Robust_Signal Finally_robust(const Robust_Signal& sp1, const pair<double, double>& interval);
Robust_Signal Globally_robust(const Robust_Signal& sp1, const pair<double, double>& interval);
Robust_Signal merge_RobustIntervals(const Robust_Signal& TimeIntervals);
double distance_min_IntervalVector(const IntervalVector& P1, const IntervalVector& P2);
double distance_min_euclid_IntervalVector(const IntervalVector& P1, const IntervalVector& P2);

std::vector<Robust_Signal> predicate_robustness(ibex::simulation& sim, const vector<IntervalVector>& predicate_list);
void print_RobustIntervals_to_file(const Robust_Signal& TimeIntervals, const string& file_path);
double robustness_at_t(const Robust_Signal& sp1, double t);
void record_satisfaction_robust(const Robust_Signal& TimeIntervals,
                                             const std::string& base_file_path,
                                             double suffix);
                                             
vector<double> bisectime_robust(const Robust_Signal& sp1, const double& robustness_val);

Robust_Signal STL_formula_robust(std::vector<Robust_Signal> predicate_robust_signal);
#endif // CSTL_Robust_H

