/* ============================================================================
 * D Y N I B E X - STL formula verification on tube
 * ============================================================================
 * Copyright   : ENSTA
 * License     : This program can be distributed under the terms of the GNU LGPL.
 *               See the file COPYING.LESSER.
 *
 * Author(s)   : Antoine Besset, Joris Tillet and Julien Alexandre dit Sandretto
 * Created     : Jul 22, 2025
 * Modified    : Jul 22, 2025
 * Sponsored   : This research benefited from the support of the "STARTS Projects - CIEDS - Institut Polytechnique"
 * ---------------------------------------------------------------------------- */
#ifndef CSTL_H
#define CSTL_H

#include <iostream>
#include <vector>
#include "ibex.h"
#include "ZonoIbex.h"
#include <unordered_set>

using namespace std;
using namespace ibex;

typedef pair<pair<int, vector<int>>, pair<double, double>> TimeInterval;
typedef std::vector<TimeInterval> Satisfaction_Signal;

// Function prototypes
vector<TimeInterval> neg_stl_titv(const vector<TimeInterval>& sp);
vector<TimeInterval> and_stl_titv(const vector<TimeInterval>& sp1, const vector<TimeInterval>& sp2);
vector<TimeInterval> or_stl_titv(const vector<TimeInterval>& sp1, const vector<TimeInterval>& sp2);
void print_TimeIntervals(const vector<TimeInterval>& TimeIntervals);
vector<TimeInterval> until_stl_minkowski(const vector<TimeInterval>& list1, const vector<TimeInterval>& list2, pair<double, double> time_itv);
vector<TimeInterval> Finally(const vector<TimeInterval>& list1, pair<double, double> time_itv);
vector<TimeInterval> Globally(const vector<TimeInterval>& list1, pair<double, double> time_itv);
vector<int> minusonecleaner(const vector<int>& input);
vector<TimeInterval> merge_TimeIntervals_Mink(const vector<TimeInterval>& TimeIntervals);
vector<TimeInterval> merge_TimeIntervals(const vector<TimeInterval>& TimeIntervals);
void print_TimeIntervals_to_file(const vector<TimeInterval>& TimeIntervals, const string& file_path);

int predicate_test_jn(const IntervalVector& aff_vec1, const IntervalVector& aff_vec2);
std::vector<int> negatif_cleaner(const std::vector<int>& input);

Satisfaction_Signal predicate_satisfaction_oneshot(const Satisfaction_Signal& certain_signal, const Satisfaction_Signal& origine ,const vector<int>& num, const int& init_marker);

//tools
void print_markers(const std::vector<int>& vec);
void print_uplets(const std::vector<vector<int>>& resphi);

Satisfaction_Signal STL_formula(const std::vector<Satisfaction_Signal>& predicate_signals);
std::vector<int> uplet_to_list(const std::vector<vector<int>>& vec);
bool exist_in_list(const std::vector<int>& init, const int& val);
std::vector<int> variant_uplet(const std::vector<int>& init,const std::vector<vector<int>>& vec);
std::vector<std::pair<IntervalVector, Interval>> Sim_to_jn_tube(ibex::simulation& sim);
std::pair<std::vector<vector<TimeInterval>>, std::vector<Interval>> predicate_satisfaction_jn(const std::vector<std::pair<IntervalVector, Interval>>& jn_box, const vector<IntervalVector>& predicate_list);
std::vector<std::pair<IntervalVector, Interval>> Append_tube(const std::vector<std::pair<IntervalVector, Interval>>& old_tube, const std::vector<std::pair<IntervalVector, Interval>>& extension_tube);
double last_time_tube(const std::vector<std::pair<IntervalVector, Interval>>&  result);
double first_time_tube(const std::vector<std::pair<IntervalVector, Interval>>&  result);
std::pair<std::vector<vector<TimeInterval>>, std::vector<Interval>> predicate_satisfaction(ibex::simulation& sim, const vector<IntervalVector>& predicate_list);
vector<double> Bisection_time(const vector<Interval>& Un_origin, const double& min_step_time, const double& t_min);
vector<Interval> Uncertainty_origin(vector<TimeInterval> Phi1, const vector<Interval>& P_Satisfaction_signals);
void process_and_save_data(ibex::simulation& sim, 
                           const vector<IntervalVector>& predicate_list, 
                           const vector<int>& selected_indices,
                           const string& predicate_file,
                           const string& jn_box_file);

int satisfies_at_time(const double& time, const vector<TimeInterval>& phi);
std::vector<std::pair<ibex::IntervalVector, ibex::Interval>> Sim_to_jn_tube_test(const ibex::simulation& sim);
void generate_combinations(const std::vector<int>& nums,
                           int k,
                           int start,
                           std::vector<int>& current,
                           std::vector<std::vector<int>>& result);
std::vector<std::vector<int>> all_k_uplets(const std::vector<int>& nums, int k);
std::vector<int> get_uncertainty_marks_at_t(const Satisfaction_Signal& Phi, const double& time);

#endif // CSTL_H

