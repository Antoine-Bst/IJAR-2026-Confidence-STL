#ifndef ZONOSIMU_H
#define ZONOSIMU_H

/* ============================================================================
 * D Y N I B E X - QuickComputation of Zonotope from Dynibex
 * ============================================================================
 * License     : GNU LGPL (see COPYING.LESSER)
 * Authors     : Antoine Besset, Joris Tillet, Julien Alexandre dit Sandretto
 * Created     : Sept 30, 2025
 * Modified    : Sept 30, 2025
 * ---------------------------------------------------------------------------- */

#include "ibex.h"
#include <vector>
#include <utility>
#include "CSTL.h"
#include "CSTL_Robust.h"
#include "ZonoIbex.h"


using namespace ibex;
using namespace std;

ZonoTube Simulation_system_adapt(const Affine2Vector& yinit_aff, const double& ministep ,const std::vector<IntervalVector>& predicate_liste_itv);

ZonoTube Simulation_system(const Affine2Vector& yinit_aff);

//const Affine2Vector& yinit_aff
ZonoTube Simulation_system_NN(const Affine2Vector& yinit_aff);

Affine2Vector ponctual_affine_vector(const double& val, const int& dim);

#endif // ZONOIBEX_H
