#include <iostream>
#include <vector>
#include <algorithm>
#include <unordered_set>
#include <fstream>
#include "ibex.h"
#include <math.h>
//#include "CSTL.h"
#include "CSTL_Robust.h"
#include "ZonoIbex.h"

using namespace ibex;
using namespace std;

//typedef pair<double, pair<double, double>> RobustInterval;
//typedef vector<vector<int>> Undef_index;
//typedef vector<RobustInterval> Robust_Signal;

//===================================================================================
//Formule STL à coder en dur
Robust_Signal STL_formula_robust(std::vector<Robust_Signal> predicate_robust_signal){

  //toujours utiliser cette structure
  Robust_Signal V = predicate_robust_signal[0];
  Robust_Signal W = predicate_robust_signal[1];
    //in order to have a precise tracking predicate should be unique in the formula even if it is necessary to duplicate the predicate set

  //écrire la formule
  Robust_Signal result =   and_stl_robust(Globally_robust(or_stl_robust(neg_stl_robust(V), Finally_robust(W, {3.5,4.5})),{0,6.7}), Finally_robust(V, {5.2,5.7}));

  return result;
}
//===================================================================================

double and_unitary(double val1, double val2) {
    return min(val1, val2);
}

double or_unitary(double val1, double val2) {
    return max(val1, val2);
}

double neg_unitary(double val){
return -val;
}

Robust_Signal completator(const Robust_Signal& sp, double fin_max) {
    if (sp.empty()) return {{-1e9, make_pair(0, fin_max)}};
    Robust_Signal resultat = sp;
    if (sp.back().second.second<fin_max)
    {
        resultat.push_back({-1e9, make_pair(sp.back().second.second, fin_max)}); //unmarked uncertainty (no knowledge)
    }
    return resultat;
}

Robust_Signal merge_RobustIntervals(const Robust_Signal& TimeIntervals) {
    if (TimeIntervals.empty()) return {};

    Robust_Signal merged;
    merged.push_back(TimeIntervals[0]);

    for (size_t i = 1; i < TimeIntervals.size(); ++i) {
        if (TimeIntervals[i].first == merged.back().first) {
            merged.back().second.second = TimeIntervals[i].second.second;            
        } else {
            merged.push_back(TimeIntervals[i]);
        }
    }
    //std::cout<<"jemerge"<<std::endl;
    return merged;
}

Robust_Signal neg_stl_robust(const Robust_Signal& sp) {
    Robust_Signal negated_TimeIntervals;
    for (size_t i = 0; i < sp.size(); i++)
    {  
        if (sp[i].first == -1e9)
        {
            negated_TimeIntervals.push_back({-1e9, sp[i].second}); //1e-9 ça veut dire qu'on ne sait pas la suite
        }
        else
        {
            negated_TimeIntervals.push_back({neg_unitary(sp[i].first), sp[i].second});
        } 
    }
    return negated_TimeIntervals;
}

Robust_Signal and_stl_robust(const Robust_Signal& sp1, const Robust_Signal& sp2) {
    double fin_max = max(sp1.empty() ? 0 : sp1.back().second.second, sp2.empty() ? 0 : sp2.back().second.second);
    Robust_Signal sp3 = completator(sp1, fin_max);
    Robust_Signal sp4 = completator(sp2, fin_max);
    Robust_Signal resultat;
    size_t i = 0, j = 0;

    while (i < sp3.size() && j < sp4.size()) {
        double v1 = sp3[i].first;
        double v2 = sp4[j].first;
        
        double debut_inter = max(sp3[i].second.first, sp4[j].second.first);
        double fin_inter = min(sp3[i].second.second, sp4[j].second.second);
        
        if (debut_inter < fin_inter) {

                resultat.push_back({and_unitary(v1, v2), {debut_inter, fin_inter}});
        }
        if (sp3[i].second.second <= sp4[j].second.second) ++i;
        else ++j;
    }
    return merge_RobustIntervals(resultat);
}


Robust_Signal or_stl_robust(const Robust_Signal& sp1, const Robust_Signal& sp2) {
    double fin_max = max(sp1.empty() ? 0 : sp1.back().second.second, sp2.empty() ? 0 : sp2.back().second.second);
    Robust_Signal sp3 = completator(sp1, fin_max);
    Robust_Signal sp4 = completator(sp2, fin_max);
    Robust_Signal resultat;
    size_t i = 0, j = 0;

    while (i < sp3.size() && j < sp4.size()) {
        double v1 = sp3[i].first;
        double v2 = sp4[j].first;
        
        double debut_inter = max(sp3[i].second.first, sp4[j].second.first);
        double fin_inter = min(sp3[i].second.second, sp4[j].second.second);
        
        if (debut_inter < fin_inter) {

                resultat.push_back({or_unitary(v1, v2), {debut_inter, fin_inter}});
        }
        if (sp3[i].second.second <= sp4[j].second.second) ++i;
        else ++j;
    }
    return merge_RobustIntervals(resultat);
}

Robust_Signal offset_time(const Robust_Signal& intervals, double offset) {
    Robust_Signal offset_intervals;
    for (const auto& interval : intervals) {
        offset_intervals.push_back(make_pair(interval.first, make_pair(interval.second.first + offset, interval.second.second + offset)));
    }
    return offset_intervals;
}

void print_RobustIntervals(const Robust_Signal& TimeIntervals) {
    for (const auto& TimeInterval : TimeIntervals) {
        cout << "[" << TimeInterval.first << ", [" << TimeInterval.second.first << ", " << TimeInterval.second.second << ")]\n";
    }
}

void print_RobustIntervals_to_file(const Robust_Signal& TimeIntervals, const string& file_path) {
    ofstream outFile(file_path); // Open file for writing

    if (!outFile) { // Check if the file is opened successfully
        cerr << "Error: Unable to open file " << file_path << endl;
        return;
    }

    for (const auto& TimeInterval : TimeIntervals) {
        if (fabs(TimeInterval.first)<1e4)
        {
            outFile << "[" << TimeInterval.first << ", (" << TimeInterval.second.first << ", " << TimeInterval.second.second << ")]\n";
        }
    }

    outFile.close(); // Close the file
    std::cout << "Output written to " << file_path << endl;
}

double robustness_at_t(const Robust_Signal& sp1, double t){
for (size_t i = 0; i < sp1.size(); i++)
{
    if (sp1[i].second.second>t)
    {
        return sp1[i].first; 
    }
}
std::cout<<"error: time out of range, robustness"<<std::endl;
return -1e9;
}

int search_index(const Robust_Signal& sp1,const double& time){
    for (size_t i = 0; i < sp1.size(); i++)
    {
        if (sp1[i].second.second>time)
        {
            return i;
        }
    }
std::cout<<"error: time out of range, index"<<std::endl;
return 0;
}

double inf_RobustItv(const Robust_Signal& sp1,const pair<double, double>& interval){
    double inf_record = 1e8;
    for (size_t i = 0; i < sp1.size(); i++)
    {
        if ((sp1[i].second.second > interval.first && interval.second >= sp1[i].second.first))
        {
            inf_record = min(inf_record, sp1[i].first);
        }
    }
    return inf_record;
}

double sup_RobustItv(const Robust_Signal& sp1,const pair<double, double>& interval){
    double inf_record = -1e8;
    for (size_t i = 0; i < sp1.size(); i++)
    {
        if ((sp1[i].second.second > interval.first && interval.second >= sp1[i].second.first))
        {
            inf_record = max(inf_record, sp1[i].first);
        }
    }
    return inf_record;
}

double Until_robust(const Robust_Signal& sp1, const Robust_Signal& sp2, const pair<double, double>& interval,const double& time)
{
    pair<int, int> itv_index_phi2 = {search_index(sp2, interval.first+time),search_index(sp2, interval.second+time)};
    //pair<int, int> itv_index_phi1 = {search_index(sp1, time),search_index(sp2, interval.second+time)};
    double max_record = -1e8;

    for (size_t i = itv_index_phi2.first; i <= itv_index_phi2.second; i++)
    {        

        if (time>sp2[i].second.first)
        {
            max_record= max(max_record, min(sp2[i].first, inf_RobustItv(sp1, {time, time})));
            //std::cout<<"inf pho phi1 "<< i <<" :"<< min(sp2[i].first, inf_RobustItv(sp1, {time, time}))<<", start time "<< time <<", stop "<<sp2[i].second.first <<std::endl;
        }
        else
        {   
            if (time + interval.first > sp2[i].second.first)
            {
                max_record= max(max_record, min(sp2[i].first, inf_RobustItv(sp1, {time, time + interval.first})));
                //std::cout<<"inf pho phi1 "<< i <<" :"<< min(sp2[i].first, inf_RobustItv(sp1, {time, time + interval.first}))<<", start time "<< time <<", stop "<<sp2[i].second.first <<std::endl;
            }
            else
            {
                max_record= max(max_record, min(sp2[i].first, inf_RobustItv(sp1, {time, sp2[i].second.first})));
                //std::cout<<"inf pho phi1 "<< i <<" :"<< min(sp2[i].first, inf_RobustItv(sp1, {time, sp2[i].second.first}))<<", start time "<< time <<", stop "<<sp2[i].second.first <<std::endl;
            }
            
        }
        
    }
    return max_record;
}

Robust_Signal Until_robust_titv(const Robust_Signal& sp1, const Robust_Signal& sp2, const pair<double, double>& interval){
double fin_max = max(sp1.back().second.second,sp2.back().second.second);
Robust_Signal result;
double step = 0.001; ///fine discretisation to avoid overcommitment
Robust_Signal sp3 = completator(sp1, fin_max);
Robust_Signal sp4 = completator(sp2, fin_max + interval.second);
double time = 0;
while (time < fin_max)
{
    result.push_back({Until_robust(sp3, sp4,interval,time),{time, time + step}});
    time = time + step;
}    
return merge_RobustIntervals(result);
}

Robust_Signal Globally_robust(const Robust_Signal& sp1, const pair<double, double>& interval){
double fin_max = sp1.back().second.second - (interval.second);
Robust_Signal result;
double step = 0.001; ///fine discretisation to avoid overcommitment
double time = 0;
while (time < fin_max)
{
    result.push_back({inf_RobustItv(sp1, {time+ interval.first, time+ interval.second}),{time, time + step}});
    //std::cout<<inf_RobustItv(sp1, {time+ interval.first, time+ interval.second})<<" robustness on g"<<std::endl;
    time = time + step;
}    
return merge_RobustIntervals(result);
}

Robust_Signal Finally_robust(const Robust_Signal& sp1, const pair<double, double>& interval){
double fin_max = sp1.back().second.second + (interval.second);
Robust_Signal sp3 = completator(sp1, fin_max);
Robust_Signal result;
double step = 0.001; ///fine discretisation to avoid overcommitment
double time = 0;
while (time < fin_max)
{
    result.push_back({sup_RobustItv(sp3, {time+ interval.first, time+ interval.second}),{time, time + step}});
    //std::cout<<inf_RobustItv(sp1, {time+ interval.first, time+ interval.second})<<" robustness on g"<<std::endl;
    time = time + step;
}    
return merge_RobustIntervals(result);
}

double distance_min_Interval(const Interval& P1, const Interval& P2){
    double result = 1e8;
        result = min(result, fabs(P1.lb()-P2.ub()));
        result = min(result, fabs(P1.lb()-P2.lb()));
        result = min(result, fabs(P1.ub()-P2.ub()));
        result = min(result, fabs(P1.ub()-P2.lb()));
    return result;
}

double distance_min_IntervalVector(const IntervalVector& P1, const IntervalVector& P2){
    double result = 1e8;
    if (P1.size()!=P2.size())
    {
    std::cout<<"Error: Cannot compute distance, set are not of the same dimensions"<<std::endl;
    return 0;
    }
    
    for (size_t i = 0; i < P1.size(); i++)
    {
        result = min(result, distance_min_Interval(P1[i],P2[i]));
    }
    
    return result;
}

double distance_min_euclid_IntervalVector(const IntervalVector& P1, const IntervalVector& P2){
    double result = 1e8;
    if (P1.size()!=P2.size())
    {
    std::cout<<"Error: Cannot compute distance, set are not of the same dimensions"<<std::endl;
    return 0;
    }
    double D2 = 0; //par défaut 0
    double temp_distance =0;
    for (size_t i = 0; i < P1.size(); i++)
    {   
        if (!P1[i].is_subset(P2[i]) && !P1[i].intersects(P2[i]))
        {
            temp_distance = distance_min_Interval(P1[i],P2[i]);
        D2 = temp_distance*temp_distance + D2;
        }
    }
    result =  sqrt(D2);
    
    return result;
}




std::vector<Robust_Signal> predicate_robustness(ibex::simulation& sim, const vector<IntervalVector>& predicate_list) {
    std::vector<std::pair<IntervalVector, Interval>> jn_box;
    for (const auto& sol : sim.list_solution_g) {
        if (sol.box_jn && (sol.time_j.lb()>=0)) { // Ensure it's not NULL
            jn_box.push_back({*sol.box_j1,sol.time_j}); // Dereference pointer
        }
    }
    //jn_box;
    int undef_counter = 0;
    std::vector<Robust_Signal> result;
    double p_val = 0;
    for (size_t j = 0; j < predicate_list.size(); j++)
    {
      Robust_Signal P_satisf;
        for (size_t i = 0; i < jn_box.size(); i++)
        {
          if (jn_box[i].first.is_subset(predicate_list[j]))
          {
            p_val = distance_min_IntervalVector(jn_box[i].first,predicate_list[j]);
          }
          else if (jn_box[i].first.intersects(predicate_list[j]))
          {
            p_val = 0;
          }
          else
          {
            //excluded
            p_val = -distance_min_euclid_IntervalVector(jn_box[i].first, predicate_list[j]);
          }
            P_satisf.push_back({p_val,{jn_box[i].second.lb(), jn_box[i].second.ub()}});
          }
      
      result.push_back(P_satisf);
    }
    //test formule

    //on reboucle
  return result;
}

void record_satisfaction_robust(const Robust_Signal& TimeIntervals,
                                             const std::string& base_file_path,
                                             double suffix) {
    std::ostringstream filename;
    filename << base_file_path << "_" << std::fixed << std::setprecision(2) << suffix << ".txt";

print_RobustIntervals_to_file(TimeIntervals, filename.str());

}

vector<double> bisectime_robust(const Robust_Signal& sp1, const double& robustness_val){
vector<double> result = {};
for (size_t i = 0; i < sp1.size(); i++)
{   
    if ((fabs(sp1[i].first) == fabs(robustness_val))&&fabs(robustness_val)!=0)
    {
        result.push_back(sp1[i].second.first*0.5 + sp1[i].second.second*0.5);
        std::cout<< "robust time = "<< sp1[i].second.first<< " index: "<< i <<" size: "<<sp1.size()<<std::endl;
    }
    
}
return result;
} //renvoyer qqch pour le predicat aussi
